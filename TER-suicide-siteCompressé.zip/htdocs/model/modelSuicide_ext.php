<?php
    require_once File::build_path(array('model', 'Model.php')); // On peut donc utiliser cette fonction 
class modelSuicide_ext {
  private $idSuicide_ext;
  private $country;
  private $year;
  private $sex;
  private $age;
  private $suicides_no;
  private $population;
  private $suicides_per_100k_pop;
  private $countryyear;
  private $HDI_for_year;
  private $_gdp_for_year_in_doller;
  private $gdp_per_capita_in_doller;
  private $generation;

  public function __construct($idSuicide_ext = NULL, $country = NULL, $year = NULL, $sex = NULL, $age = NULL, $suicides_no = NULL, $population = NULL, $suicides_per_100k_pop = NULL, $countryyear = NULL, $HDI_for_year = NULL, $_gdp_for_year_in_doller = NULL, $gdp_per_capita_in_doller = NULL, $generation = NULL) {
	  if (!is_null($idSuicide_ext) && !is_null($country) && !is_null($year) && !is_null($sex) && !is_null($age) && !is_null($suicides_no) && !is_null($population) && !is_null($suicides_per_100k_pop) && !is_null($countryyear) && !is_null($HDI_for_year) && !is_null($_gdp_for_year_in_doller) && !is_null($gdp_per_capita_in_doller) && !is_null($generation)) {
		$this->idSuicide_ext = $idSuicide_ext;
    $this->country = $country;
    $this->year = $year;
    $this->sex = $sex;
    $this->$age = $age;
    $this->$suicides_no = $suicides_no;
    $this->$population = $population;
    $this->$suicides_per_100k_pop = $suicides_per_100k_pop;
    $this->$countryyear = $countryyear;
    $this->$HDI_for_year = $HDI_for_year;
    $this->$_gdp_for_year_in_doller = $_gdp_for_year_in_doller;
    $this->$gdp_per_capita_in_doller = $gdp_per_capita_in_doller;
    $this->$generation = $generation;
	  }
  }
      
  // un getter      
  public function getidSuicide_ext() {
       return $this->idSuicide_ext;  
  }     
  // un setter 
  public function setidSuicide_ext($idSuicide_ext) {
       $this->idSuicide_ext = $idSuicide_ext;
  }
  

  // un getter      
  public function getcountry() {
       return $this->country;  
  }     
  // un setter 
  public function setcountry($country) {
       $this->country = $country;
  }
  
  // un getter      
  public function getyear() {
       return $this->year;  
  }     
  // un setter 
  public function setyear($year) {
       $this->year = $year;
  }
  
  // un getter      
  public function getsex() {
       return $this->sex;  
  }     
  // un setter 
  public function setsex($sex) {
       $this->sex = $sex;
  }
  
  public function getage() {
       return $this->age;  
  }
  public function setage($age) {
       $this->age = $age;
  }
  public function getsuicides_no() {
       return $this->suicides_no;  
  }
  public function setsuicides_no($suicides_no) {
       $this->suicides_no = $suicides_no;
  }
  public function getpopulation() {
       return $this->population;  
  }
  public function setpopulation($population) {
       $this->population = $population;
  }
  public function getsuicides_per_100k_pop() {
       return $this->suicides_per_100k_pop;  
  }
  public function setsuicides_per_100k_pop($suicides_per_100k_pop) {
       $this->suicides_per_100k_pop = $suicides_per_100k_pop;
  }
  public function getcountryyear() {
       return $this->countryyear;  
  }
  public function setcountryyear($countryyear) {
       $this->countryyear = $countryyear;
  }
  public function getHDI_for_year() {
       return $this->HDI_for_year;  
  }
  public function setHDI_for_year($HDI_for_year) {
       $this->HDI_for_year = $HDI_for_year;
  }
  public function get_gdp_for_year_in_doller() {
       return $this->_gdp_for_year_in_doller;  
  }
  public function set_gdp_for_year_in_doller($_gdp_for_year_in_doller) {
       $this->_gdp_for_year_in_doller = $_gdp_for_year_in_doller;
  }
  public function getgdp_per_capita_in_doller() {
       return $this->gdp_per_capita_in_doller;  
  }
  public function setgdp_per_capita_in_doller($gdp_per_capita_in_doller) {
       $this->gdp_per_capita_in_doller = $gdp_per_capita_in_doller;
  }
  public function getgeneration() {
       return $this->generation;  
  }
  public function setgeneration($generation) {
       $this->generation = $generation;
  
}
      public static function getAllOMSByselCategories($selCategories) { 
          try { 
              //$sql = "SELECT * FROM OMS WHERE nomMarmite LIKE '%$nomC%'"; 
              $sql = "SELECT * FROM OMS, Categories  WHERE selCategories=:selCategories AND idCategories=year ORDER BY year"; 
              $retour = Model::$pdo->prepare($sql); 
              $values = array(
                  "selCategories" => $selCategories,
              );
              $retour->execute($values);
              $retour->setFetchMode(PDO::FETCH_CLASS, 'modelSuicide_ext'); 
              $tab_obj = $retour->fetchAll(); 
              return $tab_obj;
          } catch(PDOException $e) { 
              if (Conf::getDebug()) { 
                  echo $e->getMessage(); 
              } else { 
                  echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
              } 
              die(); 
          } 
      }

  public static function updateOMSsex($idSuicide_ext, $idSuicide_extIMG) {
    $sql = "UPDATE OMS SET sex = :idSuicide_extIMG WHERE idSuicide_ext=:idSuicide_ext";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idSuicide_ext" => $idSuicide_ext,
    "idSuicide_extIMG" => $idSuicide_extIMG
    );
    $req_prep->execute($values);
  }

  public static function updateOMSpdfOMS($idSuicide_ext, $idSuicide_extPDF) {
    $sql = "UPDATE OMS SET pdfOMS = :idSuicide_extPDF WHERE idSuicide_ext=:idSuicide_ext";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idSuicide_ext" => $idSuicide_ext,
    "idSuicide_extPDF" => $idSuicide_extPDF
    );
    $req_prep->execute($values);
  }

  public static function deleteMarmite($idSuicide_ext) {
    $sql = "DELETE FROM OMS WHERE idSuicide_ext=:idSuicide_ext";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
        "idSuicide_ext" => strip_tags($idSuicide_ext),
    );
    $req_prep->execute($values);
  }

  public static function updateOMS($idSuicide_ext, $country, $year, $biographieOMS, $dateNaissanceOMS) {
    $sql = "UPDATE OMS SET country = :country, year = :year, biographieOMS = :biographieOMS, dateNaissanceOMS = :dateNaissanceOMS WHERE idSuicide_ext=:idSuicide_ext";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idSuicide_ext" => $idSuicide_ext,
    "country" => $country,
    "year" => $year,
    "biographieOMS" => $biographieOMS,
    "dateNaissanceOMS" => $dateNaissanceOMS,
    );
    $req_prep->execute($values);
  }

  //////////////////////
  public static function truncateOMS() {
    $sql = 'TRUNCATE TABLE OMS';
    $req_prep = Model::$pdo->prepare($sql);
    $req_prep->execute();
  }

  public static function createOMS($country, $year, $sex, $biographieOMS, $dateNaissanceOMS, $dateMortOMS, $lieuNaissanceOMS, $lieuMortOMS, $genreOMS) {
        try {
            $sql = 'INSERT INTO OMS (country, year, sex, biographieOMS, dateNaissanceOMS, dateMortOMS, lieuNaissanceOMS, lieuMortOMS, genreOMS) VALUES (:country, :year, :sex, :biographieOMS, :dateNaissanceOMS, :dateMortOMS, :lieuNaissanceOMS, :lieuMortOMS, :genreOMS)'; // ON DUPLICATE KEY UPDATE country=:country, year=:year, sex=:sex, biographieOMS=:biographieOMS, dateNaissanceOMS=:dateNaissanceOMS, dateMortOMS=:dateMortOMS, lieuNaissanceOMS=:lieuNaissanceOMS, lieuMortOMS=:lieuMortOMS, genreOMS=:genreOMS
            $addMembres = Model::$pdo->prepare($sql);
            $values = array(
            "country" => strip_tags($country),
            "year" => strip_tags($year),
            "sex" => strip_tags($sex),
            "biographieOMS" => strip_tags($biographieOMS),
            "dateNaissanceOMS" => strip_tags($dateNaissanceOMS),
            "dateMortOMS" => strip_tags($dateMortOMS),
            "lieuNaissanceOMS" => strip_tags($lieuNaissanceOMS),
            "lieuMortOMS" => strip_tags($lieuMortOMS),
            "genreOMS" => strip_tags($genreOMS)
            );

            $addMembres->execute($values);
        } catch(PDOException $e) {
          if (Conf::getDebug()) {
              echo $e->getMessage();
          } else {
              echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
          }
          die();
        }
    }
  public static function getAllOMS($m1,$m2) {
        try { 
            $sql = "SELECT * FROM OMS WHERE CONVERT(sex, UNSIGNED INTEGER)>=:m1 AND CONVERT(sex, UNSIGNED INTEGER)<=:m2"; 
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "m1" => $m1,
              "m2" => $m2
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelSuicide_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 

  public static function getAllSex($m1,$m2) {
        try { 
            $sql = "SELECT SUM(age) AS NB, year FROM OMS WHERE CONVERT(sex, UNSIGNED INTEGER)>=:m1 AND CONVERT(sex, UNSIGNED INTEGER)<=:m2 GROUP BY year";
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "m1" => $m1,
              "m2" => $m2
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelSuicide_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    }

  public static function getAllDateSuicide($m1,$m2) {
        try { 
            $sql = "SELECT SUM(idOMS) AS NB, sex AS DATEM FROM OMS WHERE CONVERT(sex, UNSIGNED INTEGER)>=:m1 AND CONVERT(sex, UNSIGNED INTEGER)<=:m2 GROUP BY sex"; 
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "m1" => $m1,
              "m2" => $m2
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelSuicide_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 
    
    public static function getAllAge($m1, $m2) {
        try { 
            $sql = "SELECT SUM(suicides_no) AS suicides_no, SUM(population) AS population, SUM(suicides_per_100k_pop) AS suicides_per_100k_pop, SUM(countryyear) AS countryyear, SUM(HDI_for_year) AS HDI_for_year, SUM(_gdp_for_year_in_doller) AS _gdp_for_year_in_doller, SUM(gdp_per_capita_in_doller) AS gdp_per_capita_in_doller, SUM(generation) AS generation, SUM(age0) AS age0, SUM(age1) AS age1, SUM(age2) AS age2, SUM(age3) AS age3, SUM(age4) AS age4, SUM(age5) AS age5, SUM(age6) AS age6, SUM(age7) AS age7, SUM(age8) AS age8, SUM(age9) AS age9, SUM(suicides_no0) AS suicides_no0, SUM(suicides_no1) AS suicides_no1, SUM(suicides_no2) AS suicides_no2, SUM(suicides_no3) AS suicides_no3, SUM(suicides_no4) AS suicides_no4, SUM(suicides_no5) AS suicides_no5 FROM oms WHERE CONVERT(sex, SIGNED INTEGER)>=".$m1." AND CONVERT(sex, SIGNED INTEGER)<=".$m2; 
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            //var_dump($tab_obj);
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    }

  public static function getUserByName($country) { 
        try { 
            $sql = "SELECT * FROM OMS WHERE country LIKE '%$country%'"; 
            // echo $sql;
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "country" => $country,
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelSuicide_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  } 
}
?>
