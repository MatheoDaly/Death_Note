<?php
    require_once File::build_path(array('controller', 'controllerDashboard.php'));
    require_once File::build_path(array('config', 'Conf.php'));

    class Model { 
        public static $pdo;

        public static function Init() { 
            $hostname = Conf::getHostname(); 
            $database_name = Conf::getDatabase(); 
            $login = Conf::getLogin(); 
            $password = Conf::getPassword(); 
            try { 
                self::$pdo = new PDO("mysql:host=$hostname;dbname=$database_name",$login,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")); 
                /*self::$pdo=new PDO("mysql:host=$hostname; dbname=$database_name;charset=utf8", $login, $password);*/

                self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch(PDOException $e) { 
                if (Conf::getDebug()) { 
                    echo $e->getMessage(); 
                } else {
                    echo "Une erreur est survenue ! Merci de réessayer plus tard";
                } 
                die();
            } 
        } 
    } 

    Model::Init(); 
?>


