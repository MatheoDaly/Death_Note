<?php

    require_once File::build_path(array('model', 'Model.php')); // On peut donc utiliser cette fonction 

class modelMap {

   

  private $codeMap;

  private $nameMap;

  

  public function __construct($codeMap = NULL, $nameMap = NULL) {

	  if (!is_null($codeMap) && !is_null($nameMap)) {

		$this->codeMap = $codeMap;

    $this->nameMap = $nameMap;

	  }

  }

      

  // un getter      

  public function getcodeMap() {

       return $this->codeMap;  

  }     

  // un setter 

  public function setcodeMap($codeMap) {

       $this->codeMap = $codeMap;

  }

  



  // un getter      

  public function getnameMap() {

       return $this->nameMap;  

  }     

  // un setter 

  public function setnameMap($nameMap) {

       $this->nameMap = $nameMap;

  }





      public static function getAllMapByselCategories($selCategories) { 

          try { 

              //$sql = "SELECT * FROM Map WHERE nomMarmite LIKE '%$nomC%'"; 

              $sql = "SELECT * FROM Map, Categories  WHERE selCategories=:selCategories AND idCategories=sexeMap ORDER BY sexeMap"; 

              $retour = Model::$pdo->prepare($sql); 

              $values = array(

                  "selCategories" => $selCategories,

              );

              $retour->execute($values);

              $retour->setFetchMode(PDO::FETCH_CLASS, 'modelMap'); 

              $tab_obj = $retour->fetchAll(); 

              return $tab_obj;

          } catch(PDOException $e) { 

              if (Conf::getDebug()) { 

                  echo $e->getMessage(); 

              } else { 

                  echo "Une erreur est survenue ! Merci de réessayer plus tard"; 

              } 

              die(); 

          } 

      }



  public static function updateMapanneeMap($codeMap, $codeMapIMG) {

    $sql = "UPDATE Map SET anneeMap = :codeMapIMG WHERE codeMap=:codeMap";

    $req_prep = Model::$pdo->prepare($sql);



    $values = array(

    "codeMap" => $codeMap,

    "codeMapIMG" => $codeMapIMG

    );

    $req_prep->execute($values);

  }



  public static function updateMappdfMap($codeMap, $codeMapPDF) {

    $sql = "UPDATE Map SET pdfMap = :codeMapPDF WHERE codeMap=:codeMap";

    $req_prep = Model::$pdo->prepare($sql);



    $values = array(

    "codeMap" => $codeMap,

    "codeMapPDF" => $codeMapPDF

    );

    $req_prep->execute($values);

  }



  public static function deleteMarmite($codeMap) {

    $sql = "DELETE FROM Map WHERE codeMap=:codeMap";

    $req_prep = Model::$pdo->prepare($sql);



    $values = array(

        "codeMap" => strip_tags($codeMap),

    );

    $req_prep->execute($values);

  }



  public static function updateMap($codeMap, $nameMap, $sexeMap, $biographieMap, $dateNaissanceMap) {

    $sql = "UPDATE Map SET nameMap = :nameMap, sexeMap = :sexeMap, biographieMap = :biographieMap, dateNaissanceMap = :dateNaissanceMap WHERE codeMap=:codeMap";

    $req_prep = Model::$pdo->prepare($sql);



    $values = array(

    "codeMap" => $codeMap,

    "nameMap" => $nameMap,

    "sexeMap" => $sexeMap,

    "biographieMap" => $biographieMap,

    "dateNaissanceMap" => $dateNaissanceMap,

    );

    $req_prep->execute($values);

  }



  //////////////////////

  public static function truncateMap() {

    $sql = 'TRUNCATE TABLE Map';

    $req_prep = Model::$pdo->prepare($sql);

    $req_prep->execute();

  }



  public static function createMap($nameMap, $sexeMap, $anneeMap, $biographieMap, $dateNaissanceMap, $dateMortMap, $lieuNaissanceMap, $lieuMortMap, $genreMap) {

        try {

            $sql = 'INSERT INTO Map (nameMap, sexeMap, anneeMap, biographieMap, dateNaissanceMap, dateMortMap, lieuNaissanceMap, lieuMortMap, genreMap) VALUES (:nameMap, :sexeMap, :anneeMap, :biographieMap, :dateNaissanceMap, :dateMortMap, :lieuNaissanceMap, :lieuMortMap, :genreMap)'; // ON DUPLICATE KEY UPDATE nameMap=:nameMap, sexeMap=:sexeMap, anneeMap=:anneeMap, biographieMap=:biographieMap, dateNaissanceMap=:dateNaissanceMap, dateMortMap=:dateMortMap, lieuNaissanceMap=:lieuNaissanceMap, lieuMortMap=:lieuMortMap, genreMap=:genreMap

            $addMembres = Model::$pdo->prepare($sql);

            $values = array(

            "nameMap" => strip_tags($nameMap),

            "sexeMap" => strip_tags($sexeMap),

            "anneeMap" => strip_tags($anneeMap),

            "biographieMap" => strip_tags($biographieMap),

            "dateNaissanceMap" => strip_tags($dateNaissanceMap),

            "dateMortMap" => strip_tags($dateMortMap),

            "lieuNaissanceMap" => strip_tags($lieuNaissanceMap),

            "lieuMortMap" => strip_tags($lieuMortMap),

            "genreMap" => strip_tags($genreMap)

            );



            $addMembres->execute($values);

        } catch(PDOException $e) {

          if (Conf::getDebug()) {

              echo $e->getMessage();

          } else {

              echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';

          }

          die();

        }

    }

  public static function getOMSMapCount($m1,$m2) {

        try { 

            $sql = "SELECT SUM(C.NB) AS NB, codeMap, nomMap FROM (SELECT SUM(Deaths1) AS NB, codeMap, nomMap,pays.nom,oms.anneeOMS FROM oms,map,pays WHERE paysOMS=pays.code AND pays.nom=nomMap GROUP BY paysOMS) AS C WHERE CONVERT(anneeOMS, SIGNED INTEGER)>=".$m1." AND CONVERT(anneeOMS, SIGNED INTEGER)<=".$m2." GROUP BY C.codeMap ORDER BY codeMap"; 



            //$sql = "SELECT COUNT(idOMS) AS NB, codeMap, nomMap FROM oms,map WHERE paysOMS=nomMap GROUP BY paysOMS UNION SELECT COUNT(idDashboard) AS NB, codeMap, nomMap FROM Dashboard,map WHERE paysDashboard=nomMap GROUP BY paysDashboard"; 

            $retour = Model::$pdo->query($sql); 

            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelMap'); 

            $tab_obj = $retour->fetchAll();

            return $tab_obj;

        } catch(PDOException $e) { 

            if (Conf::getDebug()) { 

                echo $e->getMessage(); 

            } else { 

                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 

            } 

            die(); 

        } 

    } 



    public static function getOMSMapCount_ext($m1,$m2) {

        try { 

            $sql = "SELECT SUM(population) AS NB, country, map.codeMap FROM OMS_ext, map WHERE map.nomMap = country AND CONVERT(year, SIGNED INTEGER)>=".$m1." AND CONVERT(year, SIGNED INTEGER)<=".$m2." GROUP BY map.codeMap"; 



            //$sql = "SELECT COUNT(idOMS) AS NB, codeMap, nomMap FROM oms,map WHERE paysOMS=nomMap GROUP BY paysOMS UNION SELECT COUNT(idDashboard) AS NB, codeMap, nomMap FROM Dashboard,map WHERE paysDashboard=nomMap GROUP BY paysDashboard"; 

            $retour = Model::$pdo->query($sql); 

            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelMap'); 

            $tab_obj = $retour->fetchAll();

            return $tab_obj;

        } catch(PDOException $e) { 

            if (Conf::getDebug()) { 

                echo $e->getMessage(); 

            } else { 

                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 

            } 

            die(); 

        } 

    }



    public static function getSuicideMapCount_ext($m1,$m2) {

        try { 

            $sql = "SELECT SUM(population) AS NB, country, map.codeMap FROM OMS_ext, map WHERE map.nomMap = country AND CONVERT(year, SIGNED INTEGER)>=".$m1." AND CONVERT(year, SIGNED INTEGER)<=".$m2." GROUP BY map.codeMap"; 



            //$sql = "SELECT COUNT(idOMS) AS NB, codeMap, nomMap FROM oms,map WHERE paysOMS=nomMap GROUP BY paysOMS UNION SELECT COUNT(idDashboard) AS NB, codeMap, nomMap FROM Dashboard,map WHERE paysDashboard=nomMap GROUP BY paysDashboard"; 

            $retour = Model::$pdo->query($sql); 

            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelMap'); 

            $tab_obj = $retour->fetchAll();

            return $tab_obj;

        } catch(PDOException $e) { 

            if (Conf::getDebug()) { 

                echo $e->getMessage(); 

            } else { 

                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 

            } 

            die(); 

        } 

    }



  public static function getWikiMapCount($m1,$m2) {

        try { 

            $sql = "SELECT SUM(C.NB) AS NB, codeMap, nomMap FROM (SELECT COUNT(idDashboard) AS NB, codeMap, nomMap,dateMortDashboard FROM Dashboard,map WHERE paysDashboard=nomMap GROUP BY paysDashboard) AS C WHERE CONVERT(dateMortDashboard, SIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, SIGNED INTEGER)<=".$m2." GROUP BY C.codeMap ORDER BY codeMap"; 

            //$sql = "SELECT COUNT(idOMS) AS NB, codeMap, nomMap FROM oms,map WHERE paysOMS=nomMap GROUP BY paysOMS UNION SELECT COUNT(idDashboard) AS NB, codeMap, nomMap FROM Dashboard,map WHERE paysDashboard=nomMap GROUP BY paysDashboard"; 

            $retour = Model::$pdo->query($sql); 

            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelMap'); 

            $tab_obj = $retour->fetchAll(); 

            return $tab_obj;

        } catch(PDOException $e) { 

            if (Conf::getDebug()) { 

                echo $e->getMessage(); 

            } else { 

                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 

            } 

            die(); 

        } 

    } 



  public static function getAllSex() {

        try { 

            $sql = "SELECT COUNT(*) AS NB, sexeMap FROM Map GROUP BY sexeMap"; 

            $retour = Model::$pdo->query($sql); 

            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelMap'); 

            $tab_obj = $retour->fetchAll(); 

            return $tab_obj;

        } catch(PDOException $e) { 

            if (Conf::getDebug()) { 

                echo $e->getMessage(); 

            } else { 

                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 

            } 

            die(); 

        } 

    }



  public static function getAllDateSuicide() {

        try { 

            $sql = "SELECT COUNT(DISTINCT codeMap) AS NB, anneeMap AS DATEM FROM Map GROUP BY anneeMap"; 

            $retour = Model::$pdo->query($sql); 

            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelMap'); 

            $tab_obj = $retour->fetchAll(); 

            return $tab_obj;

        } catch(PDOException $e) { 

            if (Conf::getDebug()) { 

                echo $e->getMessage(); 

            } else { 

                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 

            } 

            die(); 

        } 

    } 



  public static function getUserByName($nameMap) { 

        try { 

            $sql = "SELECT * FROM Map WHERE nameMap LIKE '%$nameMap%'"; 

            // echo $sql;

            $retour = Model::$pdo->prepare($sql); 

            $values = array(

              "nameMap" => $nameMap,

            ); 

            $retour->execute($values);

            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelMap'); 

            $tab_obj = $retour->fetchAll(); 

            return $tab_obj;

        } catch(PDOException $e) { 

            if (Conf::getDebug()) { 

                echo $e->getMessage(); 

            } else { 

                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 

            } 

            die(); 

        } 

  } 

}

?>

