<?php
    require_once File::build_path(array('model', 'Model.php')); // On peut donc utiliser cette fonction 
class modelOMS_ext {

  private $idOMS;
  private $country;
  private $year;
  private $sex;
  private $age;
  private $suicides_no;
  private $population;

  public function __construct($idOMS = NULL, $country = NULL, $year = NULL, $sex = NULL, $age = NULL, $suicides_no = NULL, $population = NULL) {
	  if (!is_null($idOMS) && !is_null($country) && !is_null($year) && !is_null($sex) && !is_null($age) && !is_null($suicides_no) && !is_null($population)) {
		$this->idOMS = $idOMS;
    $this->country = $country;
    $this->year = $year;
    $this->sex = $sex;
    $this->$age = $age;
    $this->$suicides_no = $suicides_no;
    $this->$population = $population;
	  }
  }
      
  // un getter      
  public function getidOMS() {
       return $this->idOMS;  
  }     
  // un setter 
  public function setidOMS($idOMS) {
       $this->idOMS = $idOMS;
  }

  // un getter      
  public function getcountry() {
       return $this->country;  
  }     
  // un setter 
  public function setcountry($country) {
       $this->country = $country;
  }
  
  // un getter      
  public function getyear() {
       return $this->year;  
  }     
  // un setter 
  public function setyear($year) {
       $this->year = $year;
  }
  
  // un getter      
  public function getsex() {
       return $this->sex;  
  }     
  // un setter 
  public function setsex($sex) {
       $this->sex = $sex;
  }
  
  public function getage() {
       return $this->age;  
  }
  public function setage($age) {
       $this->age = $age;
  }
  public function getsuicides_no() {
       return $this->suicides_no;  
  }
  public function setsuicides_no($suicides_no) {
       $this->suicides_no = $suicides_no;
  }
  public function getpopulation() {
       return $this->population;  
  }
  public function setpopulation($population) {
       $this->population = $population;
  }

      public static function getAllOMSByselCategories($selCategories) { 
          try { 
              //$sql = "SELECT * FROM OMS_ext WHERE nomMarmite LIKE '%$nomC%'"; 
              $sql = "SELECT * FROM OMS, Categories  WHERE selCategories=:selCategories AND idCategories=year ORDER BY year"; 
              $retour = Model::$pdo->prepare($sql); 
              $values = array(
                  "selCategories" => $selCategories,
              );
              $retour->execute($values);
              $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS_ext'); 
              $tab_obj = $retour->fetchAll(); 
              return $tab_obj;
          } catch(PDOException $e) { 
              if (Conf::getDebug()) { 
                  echo $e->getMessage(); 
              } else { 
                  echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
              } 
              die(); 
          } 
      }

  public static function updateOMSsex($idOMS, $idOMSIMG) {
    $sql = "UPDATE OMS SET sex = :idOMSIMG WHERE idOMS=:idOMS";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idOMS" => $idOMS,
    "idOMSIMG" => $idOMSIMG
    );
    $req_prep->execute($values);
  }

  public static function updateOMSpdfOMS($idOMS, $idOMSPDF) {
    $sql = "UPDATE OMS SET pdfOMS = :idOMSPDF WHERE idOMS=:idOMS";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idOMS" => $idOMS,
    "idOMSPDF" => $idOMSPDF
    );
    $req_prep->execute($values);
  }

  public static function deleteMarmite($idOMS) {
    $sql = "DELETE FROM OMS_ext WHERE idOMS=:idOMS";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
        "idOMS" => strip_tags($idOMS),
    );
    $req_prep->execute($values);
  }

  public static function updateOMS($idOMS, $country, $year, $biographieOMS, $dateNaissanceOMS) {
    $sql = "UPDATE OMS SET country = :country, year = :year, biographieOMS = :biographieOMS, dateNaissanceOMS = :dateNaissanceOMS WHERE idOMS=:idOMS";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idOMS" => $idOMS,
    "country" => $country,
    "year" => $year,
    "biographieOMS" => $biographieOMS,
    "dateNaissanceOMS" => $dateNaissanceOMS,
    );
    $req_prep->execute($values);
  }

  //////////////////////


    public static function getStreamgraph_OMS_ext($m1,$m2) {
        try { 
            $sql = "SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.country = 'Russia' GROUP BY a.country
UNION
SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.country = 'Belarus' GROUP BY a.country
UNION
SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.country = 'Ukraine' GROUP BY a.country
UNION
SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.country = 'Korea' GROUP BY a.country
UNION
SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.country = 'Japan' GROUP BY a.country
UNION
SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.country = 'France' GROUP BY a.country
UNION
SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.country = 'United States' GROUP BY a.country
UNION
SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.country = 'Germany' GROUP BY a.country
UNION
SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.country = 'United Kingdom' GROUP BY a.country
UNION
SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.country = 'Italy' GROUP BY a.country";
Model::$pdo->query("SET SQL_BIG_SELECTS=1;");
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 

  public static function getStreamgraph_OMS_ext_age($m1,$m2) {
        try { 
            $sql = "SELECT 
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1980) AS 's1980s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1985) AS 's1985s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1990) AS 's1990s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1995) AS 's1995s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2000) AS 's2000s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2005) AS 's2005s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2010) AS 's2010s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2015) AS 's2015s', age FROM OMS_ext a WHERE a.age = '5-14 years' GROUP BY a.age
UNION
SELECT 
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1980) AS 's1980s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1985) AS 's1985s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1990) AS 's1990s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1995) AS 's1995s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2000) AS 's2000s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2005) AS 's2005s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2010) AS 's2010s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2015) AS 's2015s', age FROM OMS_ext a WHERE a.age = '15-24 years' GROUP BY a.age
UNION
SELECT 
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1980) AS 's1980s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1985) AS 's1985s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1990) AS 's1990s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1995) AS 's1995s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2000) AS 's2000s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2005) AS 's2005s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2010) AS 's2010s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2015) AS 's2015s', age FROM OMS_ext a WHERE a.age = '25-34 years' GROUP BY a.age
UNION
SELECT 
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1980) AS 's1980s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1985) AS 's1985s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1990) AS 's1990s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1995) AS 's1995s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2000) AS 's2000s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2005) AS 's2005s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2010) AS 's2010s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2015) AS 's2015s', age FROM OMS_ext a WHERE a.age = '35-54 years' GROUP BY a.age
UNION
SELECT 
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1980) AS 's1980s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1985) AS 's1985s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1990) AS 's1990s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1995) AS 's1995s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2000) AS 's2000s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2005) AS 's2005s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2010) AS 's2010s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2015) AS 's2015s', age FROM OMS_ext a WHERE a.age = '55-74 years' GROUP BY a.age
UNION
SELECT 
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1980) AS 's1980s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1985) AS 's1985s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1990) AS 's1990s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=1995) AS 's1995s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2000) AS 's2000s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2005) AS 's2005s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2010) AS 's2010s',
(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.age = a.age AND ROUND(b.year/5)*5=2015) AS 's2015s', age FROM OMS_ext a WHERE a.age = '75+ years' GROUP BY a.age";
Model::$pdo->query("SET SQL_BIG_SELECTS=1;");
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 
  public static function truncateOMS() {
    $sql = 'TRUNCATE TABLE OMS';
    $req_prep = Model::$pdo->prepare($sql);
    $req_prep->execute();
  }

  /*SELECT (SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1980) AS 's1980s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1985) AS 's1985s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1990) AS 's1990s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=1995) AS 's1995s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2000) AS 's2000s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2005) AS 's2005s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2010) AS 's2010s',(SELECT CASE WHEN SUM(b.suicides_no) IS NOT NULL THEN SUM(b.suicides_no) ELSE 0 END AS NB FROM OMS_ext b WHERE b.country = a.country AND ROUND(b.year/5)*5=2015) AS 's2015s', country FROM OMS_ext a WHERE a.age = '5-14 years' GROUP BY a.age*/

  public static function createOMS($country, $year, $sex, $biographieOMS, $dateNaissanceOMS, $dateMortOMS, $lieuNaissanceOMS, $lieuMortOMS, $genreOMS) {
        try {
            $sql = 'INSERT INTO OMS (country, year, sex, biographieOMS, dateNaissanceOMS, dateMortOMS, lieuNaissanceOMS, lieuMortOMS, genreOMS) VALUES (:country, :year, :sex, :biographieOMS, :dateNaissanceOMS, :dateMortOMS, :lieuNaissanceOMS, :lieuMortOMS, :genreOMS)'; // ON DUPLICATE KEY UPDATE country=:country, year=:year, sex=:sex, biographieOMS=:biographieOMS, dateNaissanceOMS=:dateNaissanceOMS, dateMortOMS=:dateMortOMS, lieuNaissanceOMS=:lieuNaissanceOMS, lieuMortOMS=:lieuMortOMS, genreOMS=:genreOMS
            $addMembres = Model::$pdo->prepare($sql);
            $values = array(
            "country" => strip_tags($country),
            "year" => strip_tags($year),
            "sex" => strip_tags($sex),
            "biographieOMS" => strip_tags($biographieOMS),
            "dateNaissanceOMS" => strip_tags($dateNaissanceOMS),
            "dateMortOMS" => strip_tags($dateMortOMS),
            "lieuNaissanceOMS" => strip_tags($lieuNaissanceOMS),
            "lieuMortOMS" => strip_tags($lieuMortOMS),
            "genreOMS" => strip_tags($genreOMS)
            );

            $addMembres->execute($values);
        } catch(PDOException $e) {
          if (Conf::getDebug()) {
              echo $e->getMessage();
          } else {
              echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
          }
          die();
        }
    }
  public static function getAllOMS($m1,$m2) {
        try { 
            $sql = "SELECT country, year, sex, age, suicides_no FROM OMS_ext WHERE suicides_no != '' AND CONVERT(year, UNSIGNED INTEGER)>=:m1 AND CONVERT(year, UNSIGNED INTEGER)<=:m2 GROUP BY country,year";
            //$sql = "SELECT * FROM OMS_ext WHERE CONVERT(year, UNSIGNED INTEGER)>=:m1 AND CONVERT(year, UNSIGNED INTEGER)<=:m2"; 
            $retour = Model::$pdo->prepare($sql);
            Model::$pdo->query("SET SQL_BIG_SELECTS=1;"); 
            $values = array(
              "m1" => $m1,
              "m2" => $m2
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 

  public static function getAllSex($m1,$m2) {
        try { 
            $sql = "SELECT SUM(suicides_no) AS NB, sex FROM OMS_ext WHERE CONVERT(year, UNSIGNED INTEGER)>=:m1 AND CONVERT(year, UNSIGNED INTEGER)<=:m2 GROUP BY sex";
            $retour = Model::$pdo->prepare($sql); 
Model::$pdo->query("SET SQL_BIG_SELECTS=1;");
            $values = array(
              "m1" => $m1,
              "m2" => $m2
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    }

  public static function getAllDateSuicide($m1,$m2) {
        try { 
            //$sql = "SELECT COUNT(DISTINCT nomDashboard) AS NB, ROUND(dateMortDashboard/5)*5 AS DATEM FROM dashboard WHERE dateMortDashboard<>'' AND ROUND(dateMortDashboard/5)*5>1790 AND dateMortDashboard REGEXP '^[0-9]+$' AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2."  GROUP BY ROUND(dateMortDashboard/5)*5 ORDER BY CONVERT(DATEM, SIGNED INTEGER)";
            $sql = "SELECT SUM(suicides_no) AS NB, ROUND(year/5)*5 AS DATEM FROM OMS_ext WHERE CONVERT(year, UNSIGNED INTEGER)>=:m1 AND CONVERT(year, UNSIGNED INTEGER)<=:m2 GROUP BY ROUND(year/5)*5"; 
Model::$pdo->query("SET SQL_BIG_SELECTS=1;");
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "m1" => $m1,
              "m2" => $m2
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 
    
    public static function getAllAge($m1, $m2) {
        try { 
            $sql = "SELECT SUM(suicides_no) AS NB, age FROM OMS_ext WHERE CONVERT(year, SIGNED INTEGER)>=".$m1." AND CONVERT(year, SIGNED INTEGER)<=".$m2." GROUP BY age ORDER BY CAST(SUBSTRING_INDEX(age,'-',1) AS UNSIGNED)";
Model::$pdo->query("SET SQL_BIG_SELECTS=1;");
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS_ext'); 
            $tab_obj = $retour->fetchAll(); 
            //var_dump($tab_obj);
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    }

  public static function getUserByName($country) { 
        try { 
            $sql = "SELECT * FROM OMS_ext WHERE country LIKE '%$country%'"; 
Model::$pdo->query("SET SQL_BIG_SELECTS=1;"); 
            // echo $sql;
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "country" => $country,
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getNbSuicide($m1,$m2) { 
        try { 
            $sql = "SELECT SUM(suicides_no) AS NB FROM OMS_ext WHERE CONVERT(year, UNSIGNED INTEGER)>=".$m1." AND CONVERT(year, UNSIGNED INTEGER)<=".$m2.""; 
Model::$pdo->query("SET SQL_BIG_SELECTS=1;"); 
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getMaxPays($m1,$m2) { 
        try { 
            $sql = "SELECT MAX(s.NB) AS NB, country AS nom FROM (SELECT SUM(suicides_no) AS NB, country FROM OMS_ext WHERE CONVERT(year, UNSIGNED INTEGER)>=".$m1." AND CONVERT(year, UNSIGNED INTEGER)<=".$m2." GROUP BY country) s"; 
Model::$pdo->query("SET SQL_BIG_SELECTS=1;"); 
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getNbBDD($m1,$m2) { 
        try { 
            $sql = "SELECT COUNT(*) AS NB FROM OMS_ext WHERE CONVERT(year, UNSIGNED INTEGER)>=".$m1." AND CONVERT(year, UNSIGNED INTEGER)<=".$m2.""; 
Model::$pdo->query("SET SQL_BIG_SELECTS=1;"); 
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getAlea($m1,$m2) { 
        try { 
            $sql = "SELECT country AS NB FROM OMS_ext WHERE CONVERT(year, UNSIGNED INTEGER)>=".$m1." AND CONVERT(year, UNSIGNED INTEGER)<=".$m2." ORDER BY RAND() LIMIT 1";
Model::$pdo->query("SET SQL_BIG_SELECTS=1;"); 
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS_ext'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }
}
?>
