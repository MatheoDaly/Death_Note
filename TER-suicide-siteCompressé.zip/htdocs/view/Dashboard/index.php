<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="./view/Dashboard/img/favicon.png">

  <title>DeathNote v2 - Dashboard</title>

  <!-- Custom fonts for this template-->
  <link href="./view/Dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="./view/Dashboard/css/style.css" rel="stylesheet">

    <!-- Highcharts -->
    <script src="https://code.highcharts.com/maps/highmaps.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/data.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script src="https://code.highcharts.com/maps/modules/offline-exporting.js"></script>
    <script src="https://code.highcharts.com/mapdata/custom/world.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>

  <!-- Custom styles for this template-->
  <link href="./view/Dashboard/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">
<div id="loading">
    <img id="loading-image" src="./view/Dashboard/img/loading.gif" alt="Loading..." />
    <style type="text/css">
      #loading {
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  position: fixed;
  display: block;
  opacity: 0.7;
  background-color: #fff;
  z-index: 99;
  text-align: center;
}

#loading-image {
  position: absolute;
  top: 25%;
  left: 45%;
  z-index: 100;
}
    </style>
  </div>

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
      <?php include('view/Dashboard/sidebar.php'); ?>
    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" method="get" action="./">
            <input type="hidden" name="d" value="search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Rechercher..." aria-label="Search" aria-describedby="basic-addon2" name="nameDashboard">
              <div class="input-group-append">
                <button class="btn btn-primary" type="submit">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search" method="get" action="./">
                  <input type="hidden" name="d" value="search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <!-- Counter - Alerts -->
                <span class="badge badge-danger badge-counter">3+</span>
              </a>
              <!-- Dropdown - Alerts -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                  Alerts Center
                </h6>
                <?php include('view/Dashboard/news.php'); ?>
                <a class="dropdown-item text-center small text-gray-500" href="#">En attente de nouvelles alertes...</a>
              </div>
            </li>

            <!-- Nav Item - Messages -->
            <!-- <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i> -->
                <!-- Counter - Messages -->
                <!-- <span class="badge badge-danger badge-counter">7</span>
              </a> -->
              <!-- Dropdown - Messages -->
             <!--  <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header">
                  Message Center
                </h6>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/fn_BT9fwg_E/60x60" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div class="font-weight-bold">
                    <div class="text-truncate">Hi there! I am wondering if you can help me with a problem I've been having.</div>
                    <div class="small text-gray-500">Emily Fowler · 58m</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/AU4VPcFN4LE/60x60" alt="">
                    <div class="status-indicator"></div>
                  </div>
                  <div>
                    <div class="text-truncate">I have the photos that you ordered last month, how would you like them sent to you?</div>
                    <div class="small text-gray-500">Jae Chun · 1d</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/CS2uCrpNzJY/60x60" alt="">
                    <div class="status-indicator bg-warning"></div>
                  </div>
                  <div>
                    <div class="text-truncate">Last month's report looks great, I am very happy with the progress so far, keep up the good work!</div>
                    <div class="small text-gray-500">Morgan Alvarez · 2d</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div>
                    <div class="text-truncate">Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</div>
                    <div class="small text-gray-500">Chicken the Dog · 2w</div>
                  </div>
                </a>
                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
              </div>
            </li> -->

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">UPVM3 - MIASHS</span>
                <img class="img-profile rounded-circle" src="./view/Dashboard/img/logo.png">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <?php include('view/Dashboard/links_profile.php'); ?>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard Général</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
              <form action="" method="get" class="form-example">
              <div class="btn-group mr-2">
                <!-- <button class="btn btn-sm btn-outline-secondary">Partager</button>
                <button class="btn btn-sm btn-outline-secondary">Exporter</button> -->
                <input type="hidden" name="d" value="wiki">
                <input class="btn btn-sm btn-outline-secondary" name="m1" id="m1_id" type="month" value="2019-09" style="    border-top-left-radius: .2rem;    border-bottom-left-radius: .2rem;">
                <input class="btn btn-sm btn-outline-secondary" name="m2" id="m2_id" type="month" value="2019-09">
              </div>
              <input type="submit" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" value="Filtrer">
              <a href="./?d=wiki" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Annuler</a>
            </form>
           <!-- <span data-feather="calendar"></span> -->
            </div>
            <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
          </div>

          <!-- Content Row -->
          <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Aléatoire</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $alea_1->getnomDashboard()." ".$alea_1->getprenomDashboard(); ?>
                        <?php
                            include('view/Dashboard/simple_html_dom.php');
                            $search_query = $alea_1->getnomDashboard()." ".$alea_1->getprenomDashboard();
                            $search_query = urlencode( $search_query );
                            $html_1 = file_get_html("https://www.google.com/search?q=$search_query&tbm=isch" );
                            $image = $html_1->find('img')[8]->getAttribute('src');
                            echo '<img class="pic" style="height: 30px; position: absolute;top: -12px;left: 72px; border-left: solid #f7c649;" src="'.$image.'">';
                        ?>                      
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-dice fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Aléatoire</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $alea_2->getnomDashboard()." ".$alea_2->getprenomDashboard(); ?>
                        <?php
                            $search_query = $alea_2->getnomDashboard()." ".$alea_2->getprenomDashboard();
                            $search_query = urlencode( $search_query );
                            $html_2 = file_get_html("https://www.google.com/search?q=$search_query&tbm=isch" );
                            $image = $html_2->find('img')[8]->getAttribute('src');
                            echo '<img class="pic" style="height: 30px; position: absolute;top: -12px;left: 72px; border-left: solid #f7c649;" src="'.$image.'">';
                        ?>                      
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-dice fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Aléatoire</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $alea_3->getnomDashboard()." ".$alea_3->getprenomDashboard(); ?>
                        <?php
                            $search_query = $alea_3->getnomDashboard()." ".$alea_3->getprenomDashboard();
                            $search_query = urlencode( $search_query );
                            $html_3 = file_get_html("https://www.google.com/search?q=$search_query&tbm=isch" );
                            $image = $html_3->find('img')[8]->getAttribute('src');
                            echo '<img class="pic" style="height: 30px; position: absolute;top: -12px;left: 72px; border-left: solid #f7c649;" src="'.$image.'">';
                        ?>                      
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-dice fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Aléatoire</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $alea_4->getnomDashboard()." ".$alea_4->getprenomDashboard(); ?>
                        <?php
                            $search_query = $alea_4->getnomDashboard()." ".$alea_4->getprenomDashboard();
                            $search_query = urlencode( $search_query );
                            $html_4 = file_get_html("https://www.google.com/search?q=$search_query&tbm=isch" );
                            $image = $html_4->find('img')[8]->getAttribute('src');
                            echo '<img class="pic" style="height: 30px; position: absolute;top: -12px;left: 72px; border-left: solid #f7c649;" src="'.$image.'">';
                        ?>                      
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-dice fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Content Row -->
          <div class="row">

            <!-- Second Column -->
            <div class="col-lg-6">

              <!-- Background Gradient Utilities -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Par sexe</h6>
                </div>
                <div class="card-body">
                  <div id="container_12" style="width:50%;overflow:hidden; min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>
          <script type="text/javascript">
            // Build the chart
            Highcharts.chart('container_12', {
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    type: 'pie'
                },
                title: {
                    text: 'Données Wiki/ dbpédia'
                },
                tooltip: {
                    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                },
                plotOptions: {
                    pie: {
                         colors: [
                           '#ccdeef',
                           '#b6d2ec', 
                           '#7cb5ec'
                         ],
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: false
                        },
                        showInLegend: true
                    }
                },
                series: [{
                    name: 'Pourcentage',
                    colorByPoint: true,
                    data: [
                      <?php
                        foreach($allSex_2 as $s){ 
                          echo "{name:'".$s->getgenreDashboard()."', y: ".$s->NB."},";
                        }?>
                     ]
                }]
            });
          </script>
                </div>
              </div>

            </div>

            <!-- First Column -->
            <!-- <div class="col-lg-4">
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Par sexe</h6>
                </div>
                <div class="card-body">
                  <div id="container_11" style="  float:left;  width:50%; min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>
          <script type="text/javascript">
            // Build the chart
            Highcharts.chart('container_11', {
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    type: 'pie'
                },
                title: {
                    text: 'Données OMS'
                },
                tooltip: {
                    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: false
                        },
                        showInLegend: true
                    }
                },
                series: [{
                    name: 'Pourcentage',
                    colorByPoint: true,
                    data: [
                      <?php 
                        //foreach($allSex_1 as $s){ 
                        //  echo "{name:'".$s->getsexeOMS()."', y: ".$s->NB."},";
                        //}?>

                     ]
                }]
            });
          </script>
                </div>
              </div>
            </div> -->

            <!-- Third Column -->
            <div class="col-lg-6">

              <!-- Grayscale Utilities -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Par sexe</h6>
                </div>
                <div class="card-body">
                  <div id="container_13" style="min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>
          <script type="text/javascript">
            // Build the chart
            Highcharts.chart('container_13', {
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    type: 'pie'
                },
                title: {
                    text: 'Données OMS'
                },
                tooltip: {
                    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                },
                plotOptions: {
                    pie: {
                     colors: [
                       '#bdbdc3',
                       '#797982', 
                       '#434348'
                     ],
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: false
                        },
                        showInLegend: true
                    }
                },
                series: [{
                    name: 'Pourcentage',
                    colorByPoint: true,
                    data: [
                      <?php 
                        foreach($allSex_3 as $s){ 
                          echo "{name:'".$s->getsex()."', y: ".$s->NB."},";
                        }?>

                     ]
                }]
            });
          </script>
                </div>
              </div>
            </div>

          </div>

          <!-- Content Row -->
          <div class="">

            <!-- First Column -->
            <!-- <div class="col-lg-6">
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Par année</h6>
                </div>
                <div class="card-body">
                  <div id="container_22" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
          <script type="text/javascript">
            Highcharts.chart('container_22', {
              chart: {
                  type: 'line'
              },
              title: {
                  text: 'Suicide par décennie'
              },
              subtitle: {
                  text: 'Source: Wikipédia'
              },
              xAxis: {
                  categories: [<?php 
                        //foreach($allDateSuicide_2 as $s){ 
                        //  echo $s->DATEM.",";
                        //}?>]
              },
              yAxis: {
                  title: {
                      text: 'Nombre de suicide'
                  }
              },
              plotOptions: {
                  line: {
                      dataLabels: {
                          enabled: true
                      },
                      enableMouseTracking: false
                  }
              },
              series: [{
                  name: 'Suicides',
                  data: [<?php 
                        //foreach($allDateSuicide_2 as $s){ 
                        //  echo $s->NB.",";
                        //}?>
                        ]
              }]
          });
          </script>
                </div>
              </div>
            </div> -->

            <!-- Second Column -->
            <!-- <div class="col-lg-4">
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Par année</h6>
                </div>
                <div class="card-body">
                  <div id="container_21" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
          <script type="text/javascript">
            Highcharts.chart('container_21', {
              chart: {
                  type: 'line'
              },
              title: {
                  text: 'Suicide par année'
              },
              subtitle: {
                  text: 'Source: OMS'
              },
              xAxis: {
                  categories: [<?php 
                        //foreach($allDateSuicide_1 as $s){ 
                        //  echo $s->DATEM.",";
                        //}?>]
              },
              yAxis: {
                  title: {
                      text: 'Nombre de suicide'
                  }
              },
              plotOptions: {
                  line: {
                      dataLabels: {
                          enabled: true
                      },
                      enableMouseTracking: false
                  }
              },
              series: [{
                  name: 'Suicides',
                  data: [<?php 
                        //foreach($allDateSuicide_1 as $s){ 
                        //  echo $s->NB.",";
                        //}?>
                        ]
              }]
          });
          </script>
                </div>
              </div>

            </div> -->

            <!-- Third Column -->
            <div class="">

              <!-- Grayscale Utilities -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Par année</h6>
                </div>
                <div class="card-body">
                  <div id="container_23" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
          <script type="text/javascript">
          Highcharts.chart('container_23', {
    chart: {
        zoomType: 'xy'
    },
    title: {
        text: 'Nombre de suicide par année',
        align: 'left'
    },
    subtitle: {
        text: 'Source: Wikipédia et OMS',
        align: 'left'
    },
    xAxis: [{
        categories: [<?php 
                        foreach($allDateSuicide_3 as $s){ 
                          echo $s->DATEM.",";
                        }?>],
        crosshair: true
    }],
    yAxis: [{ // Primary yAxis
        labels: {
            format: '{value}',
            style: {
                color: 'black'
            }
        },
        title: {
            text: 'OMS',
            style: {
                color: 'black'
            }
        },
        opposite: true

    }, { // Secondary yAxis
        gridLineWidth: 0,
        title: {
            text: 'Wikipédia',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        },
        labels: {
            format: '{value}',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        }

    }],
    tooltip: {
        shared: true
    },
    legend: {
        layout: 'vertical',
        align: 'left',
        x: 80,
        verticalAlign: 'top',
        y: 55,
        floating: true,
        backgroundColor:
            Highcharts.defaultOptions.legend.backgroundColor || // theme
            'rgba(255,255,255,0.25)'
    },
    series: [{
        name: 'Wikipédia',
        type: 'spline',
        yAxis: 1,
        data:  [<?php 
                        foreach($allDateSuicide_2 as $s){ 
                          echo $s->NB.",";
                        }?>
                        ],
        tooltip: {
            valueSuffix: ' '
        }

    }, {
        name: 'OMS',
        type: 'spline',
        data:  [<?php 
                        foreach($allDateSuicide_3 as $s){ 
                          echo $s->NB.",";
                        }?>
                        ],
        tooltip: {
            valueSuffix: ' '
        }
    }],
    responsive: {
        rules: [{
            condition: {
                maxWidth: 500
            },
            chartOptions: {
                legend: {
                    floating: false,
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom',
                    x: 0,
                    y: 0
                },
                yAxis: [{
                    labels: {
                        align: 'right',
                        x: 0,
                        y: -6
                    },
                    showLastLabel: false
                }, {
                    labels: {
                        align: 'left',
                        x: 0,
                        y: -6
                    },
                    showLastLabel: false
                }, {
                    visible: false
                }]
            }
        }]
    }
});

          </script>
                </div>
              </div>
            </div>

          </div>

          <!-- Content Row -->
          <div class="">

            <!-- First Column -->
            <!-- <div class="col-lg-6">
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Par âge</h6>
                </div>
                <div class="card-body">
                  <figure class="highcharts-figure"><div id="container_age_2"></div></figure>
          <script type="text/javascript">
            Highcharts.chart('container_age_2', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Nombre de décès par âge'
    },
    subtitle: {
        text: 'Source: Wikipédia.fr'
    },
    xAxis: {
            <?php 
            //foreach($allAge as $d) echo "'".$d->AGE."',";
            ?>
        categories: [
          "At age 0 year","At age 1 year","At age 2 year","At age 3 year","At age 4 year","At age 5-9 years","At age 10-14 years","At age 15-19 years","At age 20-24 years","At age 25-29 years","At age 30-34 years","At age 35-39 years","At age 40-44 years","At age 45-49 years","At age 50-54 years","At age 55-59 years","At age 60-64 years","At age 65-69 years","At age 70-74 years","At age 75-79 years","At age 80-84 years","At age 85-89 years","At age 90-94 years","At age 95 years and above"
                  ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Nombre'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'Nombre',
        data: [<?php //foreach($allAge_2 as $d){
                //if(is_null($d->NB)) echo "0,";
                //else echo $d->NB.",";
            //} ?>]

    }]
});
          </script>
                </div>
              </div>
            </div> -->

            <!-- Second Column -->
            <!-- <div class="col-lg-4">
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Par âge</h6>
                </div>
                <div class="card-body">
                  <figure class="highcharts-figure"><div id="container_age_1"></div></figure>
          <script type="text/javascript">
            Highcharts.chart('container_age_1', {
              chart: {
                  type: 'column'
              },
              title: {
                  text: 'Nombre de décès par âge'
              },
              subtitle: {
                  text: 'Source:  OMS'
              },
              xAxis: {
                  categories: [
                      "At age 0 year","At age 1 year","At age 2 year","At age 3 year","At age 4 year","At age 5-9 years","At age 10-14 years","At age 15-19 years","At age 20-24 years","At age 25-29 years","At age 30-34 years","At age 35-39 years","At age 40-44 years","At age 45-49 years","At age 50-54 years","At age 55-59 years","At age 60-64 years","At age 65-69 years","At age 70-74 years","At age 75-79 years","At age 80-84 years","At age 85-89 years","At age 90-94 years","At age 95 years and above"
                  ],
                  crosshair: true
              },
              yAxis: {
                  min: 0,
                  title: {
                      text: 'Nombre'
                  }
              },
              tooltip: {
                  headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                  pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                      '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
                  footerFormat: '</table>',
                  shared: true,
                  useHTML: true
              },
              plotOptions: {
                  column: {
                      pointPadding: 0.2,
                      borderWidth: 0
                  }
              },
              series: [{
                  name: 'Nombre',
                  data: [<?php //foreach($allAge_1 as $d){
                        //echo $d->Deaths2.",".$d->Deaths3.",".$d->Deaths4.",".$d->Deaths5.",".$d->Deaths6.",".$d->Deaths7.",".$d->Deaths8.",".$d->Deaths9.",".$d->Deaths10.",".$d->Deaths11.",".$d->Deaths12.",".$d->Deaths13.",".$d->Deaths14.",".$d->Deaths15.",".$d->Deaths16.",".$d->Deaths17.",".$d->Deaths18.",".$d->Deaths19.",".$d->Deaths20.",".$d->Deaths21.",".$d->Deaths22.",".$d->Deaths23.",".$d->Deaths24.",".$d->Deaths25;
                      //} ?>]

              }]
          });
          </script>
                </div>
              </div>

            </div> -->

            <!-- Third Column -->
            <div class="">

              <!-- Grayscale Utilities -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Par âge</h6>
                </div>
                <div class="card-body">
                  <figure class="highcharts-figure"><div id="container_age_3"></div></figure>
          <script type="text/javascript">
            Highcharts.chart('container_age_3', {

    chart: {
        type: 'column',
        styledMode: true
    },

    title: {
        text: 'Décès par âge'
    },
 xAxis: {
                  categories: [
                      "5-14 years","15-24 years", "25-34 years","35-54 years","55-74 years","75+ years"
                  ],
                  crosshair: true
              },
    yAxis: [{
        className: 'highcharts-color-0',
        title: {
            text: 'Wikipédia'
        }
    }, {
        className: 'highcharts-color-1',
        opposite: true,
        title: {
            text: 'OMS'
        }
    }],

    plotOptions: {
        column: {
            borderRadius: 5
        }
    },

    series: [{
    name: 'Wikipédia',
        data: [<?php foreach($allAge_2 as $d){
                if(is_null($d->NB)) echo "0,";
                else echo $d->NB.",";
            } ?>]
    }, {
    name: 'OMS',
        data: [<?php foreach($allAge_3 as $d){
                        echo $d->NB.",";
                      } ?>],
        yAxis: 1
    }]

});

          </script>
          <style type="text/css">
            @import './view/Dashboard/css/highcharts.css';
          </style>
                </div>
              </div>
            </div>

          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; DeathNote v2 - Dashboard 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="./view/Dashboard/vendor/jquery/jquery.min.js"></script>
  <script src="./view/Dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="./view/Dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="./view/Dashboard/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="./view/Dashboard/vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="./view/Dashboard/js/demo/chart-area-demo.js"></script>
  <script src="./view/Dashboard/js/demo/chart-pie-demo.js"></script>
  <script type="text/javascript">
    $( document ).ready(function() {
      $('#loading').hide();
    }); 
  </script>
</body>

</html>
