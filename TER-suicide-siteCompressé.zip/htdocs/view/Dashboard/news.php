<a class="dropdown-item d-flex align-items-center" href="#">
  <div class="mr-3">
    <div class="icon-circle bg-success">
      <i class="fas fa-donate text-white"></i>
    </div>
  </div>
  <div>
    <div class="small text-gray-500">Avril 04, 2020</div>
    En route vers la dernière ligne droite! Une analyse qualitative bientôt?
  </div>
</a>
<a class="dropdown-item d-flex align-items-center" href="#">
  <div class="mr-3">
    <div class="icon-circle bg-primary">
      <i class="fas fa-file-alt text-white"></i>
    </div>
  </div>
  <div>
    <div class="small text-gray-500">Février 05, 2020</div>
    <span class="font-weight-bold">Une nouvelle version de DeathNote sortie!</span>
  </div>
</a>
<a class="dropdown-item d-flex align-items-center" href="#">
  <div class="mr-3">
    <div class="icon-circle bg-success">
      <i class="fas fa-donate text-white"></i>
    </div>
  </div>
  <div>
    <div class="small text-gray-500">Février 01, 2020</div>
    Proposition de rendez-vous pour le LDA.
  </div>
</a>
<a class="dropdown-item d-flex align-items-center" href="#">
  <div class="mr-3">
    <div class="icon-circle bg-warning">
      <i class="fas fa-exclamation-triangle text-white"></i>
    </div>
  </div>
  <div>
    <div class="small text-gray-500">December 2, 2019</div>
    Toutes les informations utiles sont ici!
  </div>
</a>