<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="./view/Dashboard/img/favicon.png">

  <title>DeathNote v2 - Dashboard</title>

  <!-- Custom fonts for this template-->
  <link href="./view/Dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="./view/Dashboard/css/style.css" rel="stylesheet">

    <!-- Highcharts -->
    <script src="https://code.highcharts.com/maps/highmaps.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/streamgraph.js"></script>
    <script src="https://code.highcharts.com/modules/data.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script src="https://code.highcharts.com/maps/modules/offline-exporting.js"></script>
    <script src="https://code.highcharts.com/mapdata/custom/world.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>

    <script src="https://code.highcharts.com/modules/timeline.js"></script>
    <script src="https://code.highcharts.com/modules/wordcloud.js"></script>

  <!-- Custom styles for this template-->
  <link href="./view/Dashboard/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body onresize="document.getElementById('LDA_fils').style.zoom=85*document.getElementById('LDA_parent').offsetWidth/1077+'%';" id="page-top">
<div id="loading">
    <img id="loading-image" src="./view/Dashboard/img/loading.gif" alt="Loading..." />
    <style type="text/css">
      #loading {
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  position: fixed;
  display: block;
  opacity: 0.7;
  background-color: #fff;
  z-index: 99;
  text-align: center;
}

#loading-image {
  position: absolute;
  top: 25%;
  left: 45%;
  z-index: 100;
}
    </style>
  </div>
  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
      <?php include('view/Dashboard/sidebar.php'); ?>
    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" method="get" action="./">
            <input type="hidden" name="d" value="search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Rechercher..." aria-label="Search" aria-describedby="basic-addon2" name="nameDashboard">
              <div class="input-group-append">
                <button class="btn btn-primary" type="submit">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search" method="get" action="./">
                  <input type="hidden" name="d" value="search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <!-- Counter - Alerts -->
                <span class="badge badge-danger badge-counter">3+</span>
              </a>
              <!-- Dropdown - Alerts -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                  Alerts Center
                </h6>
                <?php include('view/Dashboard/news.php'); ?>
                <a class="dropdown-item text-center small text-gray-500" href="#">En attente de nouvelles alertes...</a>
              </div>
            </li>

            <!-- Nav Item - Messages -->
            <!-- <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i> -->
                <!-- Counter - Messages -->
                <!-- <span class="badge badge-danger badge-counter">7</span>
              </a> -->
              <!-- Dropdown - Messages -->
             <!--  <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header">
                  Message Center
                </h6>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/fn_BT9fwg_E/60x60" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div class="font-weight-bold">
                    <div class="text-truncate">Hi there! I am wondering if you can help me with a problem I've been having.</div>
                    <div class="small text-gray-500">Emily Fowler · 58m</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/AU4VPcFN4LE/60x60" alt="">
                    <div class="status-indicator"></div>
                  </div>
                  <div>
                    <div class="text-truncate">I have the photos that you ordered last month, how would you like them sent to you?</div>
                    <div class="small text-gray-500">Jae Chun · 1d</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/CS2uCrpNzJY/60x60" alt="">
                    <div class="status-indicator bg-warning"></div>
                  </div>
                  <div>
                    <div class="text-truncate">Last month's report looks great, I am very happy with the progress so far, keep up the good work!</div>
                    <div class="small text-gray-500">Morgan Alvarez · 2d</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div>
                    <div class="text-truncate">Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</div>
                    <div class="small text-gray-500">Chicken the Dog · 2w</div>
                  </div>
                </a>
                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
              </div>
            </li> -->

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">UPVM3 - MIASHS</span>
                <img class="img-profile rounded-circle" src="./view/Dashboard/img/logo.png">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <?php include('view/Dashboard/links_profile.php'); ?>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Analyse qualitative</h1>
            <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
          </div>

          <!-- LDA -->
          <div id="LDA_parent" onresize="console.log('ok');">
            <div class="">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">LDA</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div>
                        <p>LDA est un algorithme de classification non supervisée qui va trouver des thèmes au sein des textes et les représenter sous forme de cluster. Le nombre de cluster et donc le nombre de thèmes est à définir par celui qui va implémenter l'algorithme.</p>
                        <p>A travers la visualisation on peut donc voir les cluster ainsi que les mots qui les composent.</p>
                        <p>Lorsque l'on survole un mot on peut voir son importance au sein du cluster et au sein de tous les cluster en général.</p>
                    </div>
                    <a data-toggle="collapse" href="#LDA_fils" role="button" aria-expanded="false" aria-controls="collapseExample">Afficher/cacher LDA</a>
                    <div class="collapse" id="LDA_fils" style="overflow: scroll; zoom:85%">
                        <?php include "./view/Dashboard/LDA.html";?>
                    </div>
                  <!-- <iframe id="serviceFrameSend" src="./view/Dashboard/LDA.html" width="1000" height="1000"  frameborder="0"> -->
                </div>
              </div>
            </div>
          </div>

          <!-- FIN LDA -->

          <!-- PREFIXSPAN -->
          <div>
            <div class="">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Prefixspan</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div>
                        <p>PrefixSpan est un algorithme pour découvrir des motifs séquentiels dans une chaîne de cacartère.</p>
                        <p>Ainsi, il est possible d'analyser les biographies de chaque personne suicidé afin d'en ressortir les parcours de vie. On pourra alors extraire des séquences de mots se répétant dans chaque paragraphe des biographies.</p>
                    </div>
                    <a data-toggle="collapse" href="#collapse_prefixspan" role="button" aria-expanded="false" aria-controls="collapseExample">Afficher/cacher Prefixspan</a>
                    <div class="collapse" id="collapse_prefixspan">
                        <div id="prefixspan"></div>
                        <select class="custom-select" onchange="p_chart.setSubtitle({text: 'Selection: '+this.value}); p_chart.series[0].update({data: p_data[this.value]}, true);" >
                            
                            <option value="all">Toutes les biographies</option>
                            <optgroup label="Pays">
                                <option value="france">France</option>
                                <option value="USA">United States</option>
                                <option value="germany">Germany</option>
                                <option value="japan">Italy</option>
                                <option value="UK">United Kingdom</option>
                            </optgroup>
    <!--                         <optgroup label="Profession">
                                <option value="acteur">Acteur</option>
                                <option value="ecrivain-journaliste-chercheur">Ecrivain/Journaliste/Chercheur</option>
                                <option value="sportif">Sportif</option>
                                <option value="militaire-armee">Militaire/Armée</option>
                            </optgroup> -->
                            <optgroup label="Sexe">
                                <option value="women">Femme</option>
                                <option value="men">Homme</option>
                            </optgroup>
                            <optgroup label="Age">
                                <option value="young">17-35</option>
                                <option value="medium">35-50</option>
                                <option value="aged">50-all</option>
                            </optgroup>
                            <optgroup label="Année">
                                <option value="war">1930-1950</option>
                                <option value="crisis">1990-2010</option>
                            </optgroup>
                        </select>
                        <script>
                            var p_requestURL = './view/Dashboard/source/prefixspan.json';
                            var p_request = new XMLHttpRequest();
                            var p_data;
                            var p_chart;
                            p_request.open('GET', p_requestURL);
                            p_request.responseType = 'json';
                            p_request.send();
                            p_request.onload = function() {
                            p_data = p_request.response;
                                p_chart = Highcharts.chart('prefixspan', {
                                    chart: {
                                        type: 'timeline',
                                        height: "50%",                                    
                                    },
                                    xAxis: {
                                        visible: false
                                    },
                                    yAxis: {
                                        visible: false
                                    },
                                    title: {
                                        text: 'Frise Chronologique des suicides'
                                    },
                                    subtitle: {
                                        text: 'Selection: all'
                                    },
                                    series: [{
                                        dataLabels: {
                                            connectorColor: 'silver',
                                            connectorWidth: 2,
                                        },
                                        data: p_data["trash"]
                                    }]
                                });
                            }
                        </script>
                    <div>
                </div>
              </div>
            </div>
          </div>
          <!-- FIN PREFIXSPAN -->


          <!-- TFIDF -->
          <div>
            <div class="">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">TFIDF et TF</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div>
                        <p>TF (pour term frequency) permet de ressortir les mots les plus fréquents dans les paragraphes.</p>
                        <p>La principale différence d'utilisation entre les deux méthodes est que TFIDF ne s'effectue que par biographie, quel mot est le plus fréquent alors que TF rest représenté dans toutes les bios, quels mots reviennent le plus souvent</p>
                    </div>
                    <a data-toggle="collapse" href="#collapse_tfidf" role="button" aria-expanded="false" aria-controls="collapseExample">Afficher/cacher TFIDF</a>
                    <br>
                    <a data-toggle="collapse" href="#collapse_tf" role="button" aria-expanded="false" aria-controls="collapseExample">Afficher/cacher TF</a>
                    <div class="collapse" id="collapse_tfidf">
                        <div id="tfidf"></div>
                        <select class="custom-select" onchange="tfidf_chart.setSubtitle({text: 'Selection: '+this.value}); tfidf_chart.series[0].update({data: tfidf_data[this.value]}, true);" >                        
                            <option value="all">Toutes les biographies</option>
                            <optgroup label="Pays">
                                <option value="france">France</option>
                                <option value="USA">United States</option>
                                <option value="germany">Germany</option>
                                <option value="japan">Italy</option>
                                <option value="UK">United Kingdom</option>
                            </optgroup>
                            <optgroup label="Sexe">
                                <option value="women">Femme</option>
                                <option value="men">Homme</option>
                            </optgroup>
                            <optgroup label="Age">
                                <option value="young">17-35</option>
                                <option value="medium">35-50</option>
                                <option value="aged">50-all</option>
                            </optgroup>
                            <optgroup label="Année">
                                <option value="war">1930-1950</option>
                            </optgroup>
                        </select>
                        <script>
                            var tfidf_requestURL = './view/Dashboard/source/tfidf.json';
                            var tfidf_request = new XMLHttpRequest();
                            var tfidf_data;
                            var tfidf_chart;
                            tfidf_request.open('GET', tfidf_requestURL);
                            tfidf_request.responseType = 'json';
                            tfidf_request.send();
                            tfidf_request.onload = function() {
                            tfidf_data = tfidf_request.response;
                                tfidf_chart = Highcharts.chart('tfidf', {
                                    chart: {
                                        type: 'timeline',
                                        height: "50%",                                    
                                    },
                                    xAxis: {
                                        visible: false
                                    },
                                    yAxis: {
                                        visible: false
                                    },
                                    title: {
                                        text: 'Frise - TFIDF (par biographie), quel mot est le plus fréquent'
                                    },
                                    subtitle: {
                                        text: 'Selection: all'
                                    },
                                    series: [{
                                        dataLabels: {
                                            connectorColor: 'silver',
                                            connectorWidth: 2,
                                        },
                                        data: tfidf_data["trash"]
                                    }]
                                });
                            }
                        </script>
                    </div>
                    <div class="collapse" id="collapse_tf">
                        <div id="tf"></div>
                        <select class="custom-select" onchange="tf_chart.setSubtitle({text: 'Selection: '+this.value}); tf_chart.series[0].update({data: tf_data[this.value]}, true);" >                        
                            <option value="all">Toutes les biographies</option>
                            <optgroup label="Pays">
                                <option value="france">France</option>
                                <option value="USA">United States</option>
                                <option value="germany">Germany</option>
                                <option value="japan">Italy</option>
                                <option value="UK">United Kingdom</option>
                            </optgroup>
    <!--                         <optgroup label="Profession">
                                <option value="acteur">Acteur</option>
                                <option value="ecrivain-journaliste-chercheur">Ecrivain/Journaliste/Chercheur</option>
                                <option value="sportif">Sportif</option>
                                <option value="militaire-armee">Militaire/Armée</option>
                            </optgroup> -->
                            <optgroup label="Sexe">
                                <option value="women">Femme</option>
                                <option value="men">Homme</option>
                            </optgroup>
                            <optgroup label="Age">
                                <option value="young">17-35</option>
                                <option value="medium">35-50</option>
                                <option value="aged">50-all</option>
                            </optgroup>
                            <optgroup label="Année">
                                <option value="war">1930-1950</option>
                                <option value="crisis">1990-2010</option>
                            </optgroup>
                        </select>
                        <script>
                            var tf_requestURL = './view/Dashboard/source/tf.json';
                            var tf_request = new XMLHttpRequest();
                            var tf_data;
                            var tf_chart;
                            tf_request.open('GET', tf_requestURL);
                            tf_request.responseType = 'json';
                            tf_request.send();
                            tf_request.onload = function() {
                            tf_data = tf_request.response;
                                tf_chart = Highcharts.chart('tf', {
                                    chart: {
                                        type: 'timeline',
                                        height: "50%",                                    
                                    },
                                    xAxis: {
                                        visible: false
                                    },
                                    yAxis: {
                                        visible: false
                                    },
                                    title: {
                                        text: 'Frise - TF (dans toutes les biographies), quels mots reviennent le plus souvent'
                                    },
                                    subtitle: {
                                        text: 'Selection: all'
                                    },
                                    series: [{
                                        dataLabels: {
                                            connectorColor: 'silver',
                                            connectorWidth: 2,
                                        },
                                        data: tf_data["trash"]
                                    }]
                                });
                            }
                        </script>
                    </div>
                </div>
              </div>
            </div>
          </div>
          <!-- FIN TFIDF -->

          <div>
            <div class="">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Wordcloud de Hashtags</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div>
                        <p>Twitter regorge aussi de beaucoup de récits proposés par des millions de personnes dans le monde. Dans l'optique de finaliser notre projet DeathNote, il reste intéressant de récupérer ces données pour les traiter. En effet, certaines personnes relatent leurs expériences vis à vis de cela ou encore leur propre avis vis à vis du suicide.</p>
                        <p>L'utilité de mettre en place un wordcloud de hashtags est de montrer l'évolution de la pensée des Français vis à vis du suicide dans le monde. On peut ainsi s'apercevoir par exemple que certains évènements sont plus ou moins influencés par d'autres. <small>Ce qui reste intéressant, c'est que l'étude est proposée sur une intervalle de valeur allant de 2009 à 2020.</small></p>
                    </div>
                    <a data-toggle="collapse" href="#collapse_wordcloud" role="button" aria-expanded="false" aria-controls="collapseExample">Afficher/cacher Wordcloud Hashtags</a>
                    <div class="collapse" id="collapse_wordcloud">
                        <!-- WORDCLOUD -->
                        <div id="container"></div>
                        <script>
                            var requestURL = './view/Dashboard/source/data.json';
                            var request = new XMLHttpRequest();
                            var data;
                            var chart;
                            request.open('GET', requestURL);
                            request.responseType = 'json';
                            request.send();
                            request.onload = function() {
                            data = request.response;

                        Highcharts.createElement('link', {
                            href: 'https://fonts.googleapis.com/css?family=Dosis:400,600',
                            rel: 'stylesheet',
                            type: 'text/css'
                        }, null, document.getElementsByTagName('head')[0]);
                        Highcharts.theme = {
                            colors: ['#7cb5ec', '#f7a35c', '#90ee7e', '#7798BF', '#aaeeee', '#ff0066',
                                '#eeaaee', '#55BF3B', '#DF5353', '#7798BF', '#aaeeee'],
                            chart: {
                                backgroundColor: null,
                                style: {
                                    fontFamily: 'Dosis, sans-serif'
                                }
                            },
                            title: {
                                style: {
                                    fontSize: '16px',
                                    fontWeight: 'bold',
                                    textTransform: 'uppercase'
                                }
                            },
                            tooltip: {
                                borderWidth: 0,
                                backgroundColor: 'rgba(219,219,216,0.8)',
                                shadow: false
                            },
                            legend: {
                                backgroundColor: '#F0F0EA',
                                itemStyle: {
                                    fontWeight: 'bold',
                                    fontSize: '13px'
                                }
                            },
                            xAxis: {
                                gridLineWidth: 1,
                                labels: {
                                    style: {
                                        fontSize: '12px'
                                    }
                                }
                            },
                            yAxis: {
                                minorTickInterval: 'auto',
                                title: {
                                    style: {
                                        textTransform: 'uppercase'
                                    }
                                },
                                labels: {
                                    style: {
                                        fontSize: '12px'
                                    }
                                }
                            },
                            plotOptions: {
                                candlestick: {
                                    lineColor: '#404048'
                                }
                            }
                        };
                        // Apply the theme
                        Highcharts.setOptions(Highcharts.theme);
                        chart = Highcharts.chart('container', {
                            accessibility: {
                                screenReaderSection: {
                                    beforeChartFormat: '<h5>{chartTitle}</h5>' +
                                        '<div>{chartSubtitle}</div>' +
                                        '<div>{chartLongdesc}</div>' +
                                        '<div>{viewTableButton}</div>'
                                }
                            },
                            series: [{
                                type: 'wordcloud',
                                data: data[2008][0]['hashtagsAssocies'],//[{name: "Lorem", weight: 1},{name: "lol", weight: 10}],
                                
                                minFontSize: 10,
                                maxFontSize: 100,
                                    rotation: {
                                        from: 0,
                                        to: 0,
                                    },
                                name: 'Occurrences'
                            }],
                            title: {
                                text: 'Année 2009'
                            }
                        });
                        }
                        </script>

                        <div class="d-flex justify-content-center my-4">
                            <span class="font-weight-bold indigo-text mr-2 mt-1" style=" margin-top: 0px !important; ">2009</span>
                            <input type="range" class="custom-range" id="customRange" onchange="chart.setTitle({text: 'Année '+this.value}); chart.series[0].update({data: data[this.value][0]['hashtagsAssocies']}, false); chart.redraw();" value=2009 min=2009 max=2020>
                            <span class="font-weight-bold indigo-text ml-2 mt-1" style=" margin-top: 0px !important; ">2020</span>
                        </div>
                        <!-- FIN WORDCLOUD -->
                    <div>
                </div>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; DeathNote v2 - Dashboard 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="./view/Dashboard/vendor/jquery/jquery.min.js"></script>
  <script src="./view/Dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="./view/Dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="./view/Dashboard/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="./view/Dashboard/vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="./view/Dashboard/js/demo/chart-area-demo.js"></script>
  <script src="./view/Dashboard/js/demo/chart-pie-demo.js"></script>
  <script type="text/javascript">
    $( document ).ready(function() {
      $('#loading').hide();
    }); 
  </script>
</body>

</html>