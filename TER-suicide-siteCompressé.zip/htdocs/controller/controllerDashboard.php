<?php

    require_once File::build_path(array('model', 'modelDashboard.php'));

    require_once File::build_path(array('model', 'modelOMS.php'));

    require_once File::build_path(array('model', 'modelMap.php'));

    require_once File::build_path(array('model', 'modelOMS_ext.php'));

    require_once File::build_path(array('model', 'modelSuicide_ext.php'));



class ControllerDashboard {

    public static function accueil(){

      if(isset($_GET['m1']))

        $m1 = explode("-", $_GET['m1'])[0];

      else

        $m1 = "0";

      if(isset($_GET['m2']))

        $m2 = explode("-", $_GET['m2'])[0];

      else

        $m2 = "9999";

      //$allMapCount = modelMap::getSuicideMapCount_ext($m1,$m2);

      //$allOMS = modelOMS_ext::getAllOMS($m1,$m2);

      //$allDateSuicide = modelOMS_ext::getAllDateSuicide($m1,$m2);

      $alea_1 = modelDashboard::getAlea($m1,$m2);  

      $alea_2 = modelDashboard::getAlea($m1,$m2);  

      $alea_3 = modelDashboard::getAlea($m1,$m2);  

      $alea_4 = modelDashboard::getAlea($m1,$m2);  



      $allSex_1 = modelOMS::getAllSex($m1,$m2);

      $allSex_2 = modelDashboard::getAllSex($m1,$m2);

      $allSex_3 = modelOMS_ext::getAllSex($m1,$m2);

      $allDateSuicide_1 = modelOMS::getAllDateSuicide($m1,$m2);

      $allDateSuicide_2 = modelDashboard::getAllDateSuicide($m1,$m2);

      $allDateSuicide_3 = modelOMS_ext::getAllDateSuicide($m1,$m2);

      $allAge_1 = modelOMS::getAllAge($m1,$m2);

      $allAge_2 = modelDashboard::getAllAge($m1,$m2);

      $allAge_3 = modelOMS_ext::getAllAge($m1,$m2);

      require_once File::build_path(array('view','Dashboard', 'index.php'));

    }





    public static function wiki() {

    modelDashboard::truncateDashboard();



    $fileName = File::build_path(array('true_stock.csv'));

    //var_dump($fileName);

    $file = fopen($fileName, "r");

    $skip = false;

    while (($column = fgetcsv($file, 100000, ";")) !== FALSE) {

      if($skip == true){ 

        if (strpos($column[0], '_') !== false)

          $nomDashboard = explode("_",$column[0])[1];

        else

          $nomDashboard = $column[0];



        if (strpos($column[0], '_') !== false)

          $prenomDashboard = explode("_",$column[0])[0];

        else

          $prenomDashboard = NULL;



        $urlDashboard=$column[1];

        if(isset($column[2])){

          $biographieDashboard_1 = str_replace("[]","",$column[2]);

          $biographieDashboard_1 = str_replace("['","",str_replace('id="Biographie"',"",str_replace(">Biographie[modifier | modifier le code]","",str_replace("', '", " ", $biographieDashboard_1)))); 

       } else

          $biographieDashboard_1=NULL;

        if(isset($column[3]))

          $biographieDashboard_2=$column[3]; 

        else

          $biographieDashboard_2=NULL;

        

        //$biographieDashboard=$biographieDashboard_1."\n".$biographieDashboard_2;

        $biographieDashboard=$biographieDashboard_1;



        if(isset($column[4]))

          if (strpos($column[4], "-") !== false)

            $dateNaissanceDashboard=explode("-",$column[4])[0];

          elseif (strpos($column[4], "/") !== false)

            $dateNaissanceDashboard=explode("/",$column[4])[2];

          else            

            $dateNaissanceDashboard=NULL;

        else

          $dateNaissanceDashboard=NULL;



        if(isset($column[5]))

          $lieuNaissanceDashboard=$column[5]; 

        else

          $lieuNaissanceDashboard=NULL;



        if(isset($column[7]))

          if (strpos($column[7], "-") !== false)

            $dateMortDashboard=explode("-",$column[7])[0];

          elseif (strpos($column[7], "/") !== false)

            $dateMortDashboard=explode("/",$column[7])[2];

          else

            $dateMortDashboard=NULL;

        else

          $dateMortDashboard=NULL;

        

        if(isset($column[8]))

          $lieuMortDashboard=$column[8]; 

        else

          $lieuMortDashboard=NULL;



        if(isset($column[10]))

          $genreDashboard = $column[10];

        else

          $genreDashboard=NULL;



        if(isset($column[11]))

          $paysDashboard = str_replace('_',' ',$column[11]);

        elseif(isset($column[12]))

          $paysDashboard = str_replace('_',' ',$column[12]);

        else

          $paysDashboard=NULL;



        modelDashboard::createDashboard($nomDashboard, $prenomDashboard, $urlDashboard, $biographieDashboard, $dateNaissanceDashboard, $dateMortDashboard, $lieuNaissanceDashboard, $lieuMortDashboard, $genreDashboard,$paysDashboard);



      }

      $skip = true;

    }

      if(isset($_GET['m1']))

        $m1 = explode("-", $_GET['m1'])[0];

      else

        $m1 = "0";

      if(isset($_GET['m2']))

        $m2 = explode("-", $_GET['m2'])[0];

      else

        $m2 = "9999";



      $nbSuicide = modelDashboard::getNbSuicide($m1,$m2);  

      $ageMoyen = modelDashboard::getAgeMoyen($m1,$m2);  

      $nbBDD = $nbSuicide;  

      $alea = modelDashboard::getAlea($m1,$m2);  



      $allDateSuicide = modelDashboard::getAllDateSuicide_PERSO($m1,$m2);

      $allSex = modelDashboard::getAllSex($m1,$m2);

      $allAge = modelDashboard::getAllAge_PERSO($m1,$m2);

      $allMapCount = modelMap::getWikiMapCount($m1,$m2);



      $streamgraph = modelDashboard::getStreamgraph_3($m1,$m2);

/*      $streamgraph_ABS = [];

      foreach($allDateSuicide as $s){ 

        array_push($streamgraph_ABS, $key->ABS);

        echo $s->DATEM.",";

      }

      $pays = $streamgraph[0]->getpaysDashboard();

      foreach ($streamgraph as $key) {

        if($key->getpaysDashboard() == $pays){

          foreach($allDateSuicide as $s){ 

            if()

            echo $s->DATEM.",";

          }

        }

      }*/

      //$streamgraph_ABS = array_unique($streamgraph_ABS); 

      //var_dump($streamgraph_ABS);  

      require_once File::build_path(array('view','Dashboard', 'wiki.php'));

    }



    public static function error404(){
      require_once File::build_path(array('view','Dashboard', 'error404.php'));
    }
    public static function maintenance(){
      require_once File::build_path(array('view','Dashboard', 'maintenance.php'));
    }
    public static function test_maintenance(){
      require_once File::build_path(array('view','Dashboard', 'test_maintenance.php'));
    }
    public static function quali(){
      require_once File::build_path(array('view','Dashboard', 'quali.php'));
    }
    



    public static function search(){

      /*$searchUser = modelDashboard::getUserByName($_GET["nameDashboard"]);

      require_once File::build_path(array('view','Dashboard', 'search.php'));*/

      //controllerDashboard::tableWiki();

      //https://fr.wikipedia.org/w/index.php?search=coucou+le+loup

      if(isset($_GET["nameDashboard"])){

        $link = "https://fr.wikipedia.org/w/index.php?search=".str_replace(" ","+",$_GET["nameDashboard"]);

        //header("Location:".$link);

      }

      else

        $link = "";

      require_once File::build_path(array('view','Dashboard', 'search.php'));

    }



/*    public static function lemm(){

      $text = array('Je mange une pomme et je joue à la console.');

      getStatistics($text, 'fr', 'fr',2);

      listSuffixes('fr');

    }*/





    /*public static function index(){

      require_once File::build_path(array('view','Dashboard', 'accueil.php'));      

    }*/



    public static function oms(){

      if(isset($_GET['m1']))

        $m1 = explode("-", $_GET['m1'])[0];

      else

        $m1 = "0";

      if(isset($_GET['m2']))

        $m2 = explode("-", $_GET['m2'])[0];

      else

        $m2 = "9999";



      $nbSuicide = modelOMS::getNbSuicide($m1,$m2);  

      $maxPays = modelOMS::getMaxPays($m1,$m2);  

      $nbBDD = modelOMS::getNbBDD($m1,$m2);  

      $alea = modelOMS::getAlea($m1,$m2);  



      $allMapCount = modelMap::getOMSMapCount($m1,$m2);

      $allDateSuicide = modelOMS::getAllDateSuicide($m1,$m2);

      $allSex = modelOMS::getAllSex($m1,$m2);

      $allAge = modelOMS::getAllAge($m1,$m2);

      require_once File::build_path(array('view','Dashboard', 'oms.php'));

    }



    public static function oms_ext(){

      if(isset($_GET['m1']))

        $m1 = explode("-", $_GET['m1'])[0];

      else

        $m1 = "0";

      if(isset($_GET['m2']))

        $m2 = explode("-", $_GET['m2'])[0];

      else

        $m2 = "9999";

      $nbSuicide = modelOMS_ext::getNbSuicide($m1,$m2);  

      $maxPays = modelOMS_ext::getMaxPays($m1,$m2);  

      $nbBDD = modelOMS_ext::getNbBDD($m1,$m2);  

      $alea = modelOMS_ext::getAlea($m1,$m2);  



      $allMapCount = modelMap::getOMSMapCount_ext($m1,$m2);

      $allDateSuicide = modelOMS_ext::getAllDateSuicide($m1,$m2);

      $allSex = modelOMS_ext::getAllSex($m1,$m2);

      $allAge = modelOMS_ext::getAllAge($m1,$m2);



      $streamgraph = modelOMS_ext::getStreamgraph_OMS_ext($m1,$m2);
      $streamgraph_age = modelOMS_ext::getStreamgraph_OMS_ext_age($m1,$m2);

      require_once File::build_path(array('view','Dashboard', 'oms_ext.php'));

    }



    public static function comparaison(){

      if(isset($_GET['m1']))

        $m1 = explode("-", $_GET['m1'])[0];

      else

        $m1 = "0";

      if(isset($_GET['m2']))

        $m2 = explode("-", $_GET['m2'])[0];

      else

        $m2 = "9999";

      //$allMapCount = modelMap::getSuicideMapCount_ext($m1,$m2);

      //$allOMS = modelOMS_ext::getAllOMS($m1,$m2);

      //$allDateSuicide = modelOMS_ext::getAllDateSuicide($m1,$m2);

      $allSex_1 = modelOMS::getAllSex($m1,$m2);

      $allSex_2 = modelDashboard::getAllSex($m1,$m2);

      $allSex_3 = modelOMS_ext::getAllSex($m1,$m2);

      $allDateSuicide_1 = modelOMS::getAllDateSuicide($m1,$m2);

      $allDateSuicide_2 = modelDashboard::getAllDateSuicide($m1,$m2);

      $allDateSuicide_3 = modelOMS_ext::getAllDateSuicide($m1,$m2);

      $allAge_1 = modelOMS::getAllAge($m1,$m2);

      $allAge_2 = modelDashboard::getAllAge($m1,$m2);

      $allAge_3 = modelOMS_ext::getAllAge($m1,$m2);

      require_once File::build_path(array('view','Dashboard', 'comparaison.php'));

    }



    public static function tableWiki(){

      if(isset($_GET['m1']))

        $m1 = explode("-", $_GET['m1'])[0];

      else

        $m1 = "0";

      if(isset($_GET['m2']))

        $m2 = explode("-", $_GET['m2'])[0];

      else

        $m2 = "9999";

      $allDashboard = modelDashboard::getAllDashboard($m1,$m2);

      require_once File::build_path(array('view','Dashboard', 'table_Wiki.php'));  

    }



    public static function tableOMS(){

      if(isset($_GET['m1']))

        $m1 = explode("-", $_GET['m1'])[0];

      else

        $m1 = "0";

      if(isset($_GET['m2']))

        $m2 = explode("-", $_GET['m2'])[0];

      else

        $m2 = "9999";

      $allOMS = modelOMS::getAllOMS($m1,$m2);

      require_once File::build_path(array('view','Dashboard', 'table_OMS.php'));  

    }



    public static function tableOMS_ext(){

      if(isset($_GET['m1']))

        $m1 = explode("-", $_GET['m1'])[0];

      else

        $m1 = "0";

      if(isset($_GET['m2']))

        $m2 = explode("-", $_GET['m2'])[0];

      else

        $m2 = "9999";

      $allOMS = modelOMS_ext::getAllOMS($m1,$m2);

      require_once File::build_path(array('view','Dashboard', 'table_OMS_ext.php'));  

    }



    public static function equipe(){

      require_once File::build_path(array('view','Dashboard', 'equipe.php'));      

    }



    public static function streamgraph(){

      require_once File::build_path(array('view','Dashboard', 'streamgraph.php'));      

    }



    //AJAX JSON de gestionnaire

    public static function streamgraph_search(){

      // Récupération du paramètre NomEleve passé dans la requête ajax dans mon ajaxGestion.js

      $NomEleve=$_POST['value'];

      //on extrait le personnel qui possède le matricule indiqué en POST

        /*$tab_v= modelPersonnels::getAllPersonnelsByMatricule($NomEleve); 

      foreach($tab_v as $v){

        $nom=$v->getNom();

        $prenom=$v->getPrenom();

        $nomp=$v->getNomP();

        $rpps=$v->getrpps();

        $service=$v->getservice();

        $debutContrat=$v->getdebutContrat();

        $finContrat=$v->getfinContrat();

        $matricule=$v->getMatricule();

      }*/

        // Ecriture de l'objet JSON contenant les infos qui vont être renvoyées

        header('Content-type: application/json');   

        echo '{"nom": "'.$NomEleve.'"}';

        //echo  '{"nom": "'.$nom.'","prenom": "'.$prenom.'","nomp": "'.$nomp.'","rpps": "'.$rpps.'","service": "'.$service.'","debutContrat": "'.$debutContrat.'","finContrat": "'.$finContrat.'","matricule": "'.$NomEleve.'"}';

    } 



}

?>

