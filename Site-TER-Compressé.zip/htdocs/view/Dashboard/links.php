<div class="bg-white py-2 collapse-inner rounded">
    <h6 class="collapse-header">Text mining</h6>
    <a class="collapse-item" title="Algorithme d'exploration de motif séquentiel fréquent" href="https://pypi.org/project/prefixspan/">Prefixspan</a>
    <a class="collapse-item" title="Analyse de cluster de thèmes communs" href="https://towardsdatascience.com/lda-topic-modeling-an-explanation-e184c90aadcd">LDA</a>
    <a class="collapse-item" title="Traitement de texte simplifié" href="https://github.com/sloria/textblob-fr">Textblob</a>
    <a class="collapse-item" href="http://alx2002.free.fr/utilitarism/stemmer/stemmer_fr.html"><small>Lemmatisation en PHP</small></a>
    <div class="collapse-divider"></div>
    <h6 class="collapse-header">Sources</h6>
    <a class="collapse-item" href="https://fr.wikipedia.org/wiki/Cat%C3%A9gorie:Mort_par_suicide">Données Wikipédia</a>
    <a class="collapse-item" href="https://www.who.int/mental_health/prevention/suicide/suicideprevent/en/">Données OMS</a>
<!--     <div class="collapse-divider"></div>
    <h6 class="collapse-header">Autres pages:</h6>
    <a class="collapse-item" href="404.html">404 Page</a>
    <a class="collapse-item" href="blank.html">Blank Page</a> -->
</div>