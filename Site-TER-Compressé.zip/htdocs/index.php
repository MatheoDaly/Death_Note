<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
  define('ROOT_FOLDER', __DIR__); //permettre de changer fichier direction selon les OS
  define('DS', DIRECTORY_SEPARATOR); //pareil mais en changeant les / en \ selon les OS
  require_once ('lib'.DS.'File.php');
  require_once File::build_path(array('controller', 'routeur.php'));
?>