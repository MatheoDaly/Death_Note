<?php
    require_once File::build_path(array('model', 'Model.php')); // On peut donc utiliser cette fonction 
class modelDashboard {
   
  private $idDashboard;
  private $nomDashboard;
  private $prenomDashboard;
  private $urlDashboard;
  private $biographieDashboard;
  private $dateNaissanceDashboard;
  private $dateMortDashboard;
  private $lieuNaissanceDashboard;
  private $lieuMortDashboard;
  private $genreDashboard;
  private $paysDashboard;
  
  public function __construct($idDashboard = NULL, $nomDashboard = NULL, $prenomDashboard = NULL, $urlDashboard = NULL, $biographieDashboard = NULL, $dateNaissanceDashboard = NULL, $dateMortDashboard = NULL, $lieuNaissanceDashboard = NULL, $lieuMortDashboard = NULL, $genreDashboard = NULL, $paysDashboard = NULL) {
	  if (!is_null($idDashboard) && !is_null($nomDashboard) && !is_null($prenomDashboard) && !is_null($urlDashboard) && !is_null($biographieDashboard) && !is_null($dateNaissanceDashboard) && !is_null($dateMortDashboard) && !is_null($lieuNaissanceDashboard) && !is_null($lieuMortDashboard) && !is_null($genreDashboard) && !is_null($paysDashboard)) {
		$this->idDashboard = $idDashboard;
    $this->nomDashboard = $nomDashboard;
    $this->prenomDashboard = $prenomDashboard;
    $this->urlDashboard = $urlDashboard;
    $this->biographieDashboard = $biographieDashboard;
    $this->dateNaissanceDashboard = $dateNaissanceDashboard;
    $this->dateMortDashboard = $dateMortDashboard;
    $this->lieuNaissanceDashboard = $lieuNaissanceDashboard;
    $this->lieuMortDashboard = $lieuMortDashboard;
    $this->genreDashboard = $genreDashboard;
    $this->paysDashboard = $paysDashboard;
	  }
  }
      
  // un getter      
  public function getidDashboard() {
       return $this->idDashboard;  
  }     
  // un setter 
  public function setidDashboard($idDashboard) {
       $this->idDashboard = $idDashboard;
  }
  

  // un getter      
  public function getnomDashboard() {
       return $this->nomDashboard;  
  }     
  // un setter 
  public function setnomDashboard($nomDashboard) {
       $this->nomDashboard = $nomDashboard;
  }
  
  // un getter      
  public function getprenomDashboard() {
       return $this->prenomDashboard;  
  }     
  // un setter 
  public function setprenomDashboard($prenomDashboard) {
       $this->prenomDashboard = $prenomDashboard;
  }
  
  // un getter      
  public function geturlDashboard() {
       return $this->urlDashboard;  
  }     
  // un setter 
  public function seturlDashboard($urlDashboard) {
       $this->urlDashboard = $urlDashboard;
  }
  
  // un getter      
  public function getbiographieDashboard() {
       return $this->biographieDashboard;  
  }     
  // un setter 
  public function setbiographieDashboard($biographieDashboard) {
       $this->biographieDashboard = $biographieDashboard;
  }
  
  // un getter      
  public function getdateNaissanceDashboard() {
       return $this->dateNaissanceDashboard;  
  }     
  // un setter 
  public function setdateNaissanceDashboard($dateNaissanceDashboard) {
       $this->dateNaissanceDashboard = $dateNaissanceDashboard;
  }

  // un getter      
  public function getdateMortDashboard() {
       return $this->dateMortDashboard;  
  }     
  // un setter 
  public function setdateMortDashboard($dateMortDashboard) {
       $this->dateMortDashboard = $dateMortDashboard;
  }

  // un getter      
  public function getlieuNaissanceDashboard() {
       return $this->lieuNaissanceDashboard;  
  }     
  // un setter 
  public function setlieuNaissanceDashboard($lieuNaissanceDashboard) {
       $this->lieuNaissanceDashboard = $lieuNaissanceDashboard;
  }

  // un getter      
  public function getlieuMortDashboard() {
       return $this->lieuMortDashboard;  
  }     
  // un setter 
  public function setlieuMortDashboard($lieuMortDashboard) {
       $this->lieuMortDashboard = $lieuMortDashboard;
  }

  // un getter      
  public function getgenreDashboard() {
       return $this->genreDashboard;  
  }     
  // un setter 
  public function setgenreDashboard($genreDashboard) {
       $this->genreDashboard = $genreDashboard;
  }

  // un getter      
  public function getpaysDashboard() {
       return $this->paysDashboard;  
  }     
  // un setter 
  public function setpaysDashboard($paysDashboard) {
       $this->paysDashboard = $paysDashboard;
  }



      public static function getAllDashboardByselCategories($selCategories) { 
          try { 
              //$sql = "SELECT * FROM Dashboard WHERE nomMarmite LIKE '%$nomC%'"; 
              $sql = "SELECT * FROM Dashboard, Categories  WHERE selCategories=:selCategories AND idCategories=prenomDashboard ORDER BY prenomDashboard"; 
              $retour = Model::$pdo->prepare($sql); 
              $values = array(
                  "selCategories" => $selCategories,
              );
              $retour->execute($values);
              $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
              $tab_obj = $retour->fetchAll(); 
              return $tab_obj;
          } catch(PDOException $e) { 
              if (Conf::getDebug()) { 
                  echo $e->getMessage(); 
              } else { 
                  echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
              } 
              die(); 
          } 
      }

  public static function updateDashboardurlDashboard($idDashboard, $idDashboardIMG) {
    $sql = "UPDATE Dashboard SET urlDashboard = :idDashboardIMG WHERE idDashboard=:idDashboard";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idDashboard" => $idDashboard,
    "idDashboardIMG" => $idDashboardIMG
    );
    $req_prep->execute($values);
  }

  public static function updateDashboardpdfDashboard($idDashboard, $idDashboardPDF) {
    $sql = "UPDATE Dashboard SET pdfDashboard = :idDashboardPDF WHERE idDashboard=:idDashboard";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idDashboard" => $idDashboard,
    "idDashboardPDF" => $idDashboardPDF
    );
    $req_prep->execute($values);
  }

  public static function deleteMarmite($idDashboard) {
    $sql = "DELETE FROM Dashboard WHERE idDashboard=:idDashboard";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
        "idDashboard" => strip_tags($idDashboard),
    );
    $req_prep->execute($values);
  }

  public static function updateDashboard($idDashboard, $nomDashboard, $prenomDashboard, $biographieDashboard, $dateNaissanceDashboard) {
    $sql = "UPDATE Dashboard SET nomDashboard = :nomDashboard, prenomDashboard = :prenomDashboard, biographieDashboard = :biographieDashboard, dateNaissanceDashboard = :dateNaissanceDashboard WHERE idDashboard=:idDashboard";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idDashboard" => $idDashboard,
    "nomDashboard" => $nomDashboard,
    "prenomDashboard" => $prenomDashboard,
    "biographieDashboard" => $biographieDashboard,
    "dateNaissanceDashboard" => $dateNaissanceDashboard,
    );
    $req_prep->execute($values);
  }

  //////////////////////
  public static function truncateDashboard() {
    $sql = 'TRUNCATE TABLE Dashboard';
    $req_prep = Model::$pdo->prepare($sql);
    $req_prep->execute();
  }

  public static function createDashboard($nomDashboard, $prenomDashboard, $urlDashboard, $biographieDashboard, $dateNaissanceDashboard, $dateMortDashboard, $lieuNaissanceDashboard, $lieuMortDashboard, $genreDashboard,$paysDashboard) {
        try {
            $sql = 'INSERT INTO Dashboard (nomDashboard, prenomDashboard, urlDashboard, biographieDashboard, dateNaissanceDashboard, dateMortDashboard, lieuNaissanceDashboard, lieuMortDashboard, genreDashboard, paysDashboard) VALUES (:nomDashboard, :prenomDashboard, :urlDashboard, :biographieDashboard, :dateNaissanceDashboard, :dateMortDashboard, :lieuNaissanceDashboard, :lieuMortDashboard, :genreDashboard, :paysDashboard)'; // ON DUPLICATE KEY UPDATE nomDashboard=:nomDashboard, prenomDashboard=:prenomDashboard, urlDashboard=:urlDashboard, biographieDashboard=:biographieDashboard, dateNaissanceDashboard=:dateNaissanceDashboard, dateMortDashboard=:dateMortDashboard, lieuNaissanceDashboard=:lieuNaissanceDashboard, lieuMortDashboard=:lieuMortDashboard, genreDashboard=:genreDashboard
            $addMembres = Model::$pdo->prepare($sql);
            $values = array(
            "nomDashboard" => strip_tags($nomDashboard),
            "prenomDashboard" => strip_tags($prenomDashboard),
            "urlDashboard" => strip_tags($urlDashboard),
            "biographieDashboard" => strip_tags($biographieDashboard),
            "dateNaissanceDashboard" => strip_tags($dateNaissanceDashboard),
            "dateMortDashboard" => strip_tags($dateMortDashboard),
            "lieuNaissanceDashboard" => strip_tags($lieuNaissanceDashboard),
            "lieuMortDashboard" => strip_tags($lieuMortDashboard),
            "genreDashboard" => strip_tags($genreDashboard),
            "paysDashboard" => strip_tags($paysDashboard)
            );

            $addMembres->execute($values);
        } catch(PDOException $e) {
          if (Conf::getDebug()) {
              echo $e->getMessage();
          } else {
              echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
          }
          die();
        }
    }
  public static function getAllDashboard($m1,$m2) {
        try { 
            $sql = "SELECT * FROM Dashboard WHERE CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2; 
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    }


  public static function getAllSex($m1,$m2) {
        try { 
            $sql = "SELECT COUNT(DISTINCT nomDashboard) AS NB, genreDashboard FROM Dashboard WHERE CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." GROUP BY genreDashboard"; 
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    }

    public static function getAllAge_PERSO($m1,$m2) {
        try { 
            //$sql = "SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE FROM `Dashboard` GROUP BY (dateMortDashboard-dateNaissanceDashboard)"; 
            $sql = "SELECT SUM(CT.NB) as NB, 'Deaths2' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE=0 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths3' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE=1 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths4' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE=2 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths5' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE=3 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths6' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE=4 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths7' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=5 AND CT.AGE<=9 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths8' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=10 AND CT.AGE<=14 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths9' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=15 AND CT.AGE<=19 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths10' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=20 AND CT.AGE<=24 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths11' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=25 AND CT.AGE<=29 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths12' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=30 AND CT.AGE<=34 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths13' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=35 AND CT.AGE<=39 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths14' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=40 AND CT.AGE<=44 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths15' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=45 AND CT.AGE<=49 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths16' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=50 AND CT.AGE<=54 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths17' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=55 AND CT.AGE<=59 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths18' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=60 AND CT.AGE<=64 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths19' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=65 AND CT.AGE<=69 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths20' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=70 AND CT.AGE<=74 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths21' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=75 AND CT.AGE<=79 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths22' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=80 AND CT.AGE<=84 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths23' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=85 AND CT.AGE<=89 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths24' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=90 AND CT.AGE<=94 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths25' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=95";
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    }

    public static function getAllAge($m1,$m2) {
        try { 
            //$sql = "SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE FROM `Dashboard` GROUP BY (dateMortDashboard-dateNaissanceDashboard)"; 
            $sql = "SELECT SUM(CT.NB) as NB, 'Deaths6' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=5 AND CT.AGE<=14 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths7' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=15 AND CT.AGE<=24 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths8' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=25 AND CT.AGE<=34 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths9' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=35 AND CT.AGE<=54 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths10' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=55 AND CT.AGE<=74 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT SUM(CT.NB) as NB, 'Deaths11' FROM (SELECT COUNT((dateMortDashboard-dateNaissanceDashboard)) AS NB,(dateMortDashboard-dateNaissanceDashboard) AS AGE, dateMortDashboard FROM Dashboard GROUP BY (dateMortDashboard-dateNaissanceDashboard)) AS CT WHERE CT.AGE>=75 AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    }

  public static function getAllDateSuicide_PERSO($m1,$m2) {
        try { 
            //$sql = "SELECT COUNT(DISTINCT nomDashboard) AS NB, dateMortDashboard AS DATEM FROM Dashboard WHERE dateMortDashboard<>'' AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." UNION SELECT COUNT(DISTINCT nomDashboard) AS NB, dateMortDashboard AS DATEM FROM Dashboard WHERE dateMortDashboard<>'' AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." AND dateMortDashboard REGEXP '^[0-9]+$' GROUP BY DATEM ORDER BY CONVERT(DATEM, SIGNED INTEGER)";
            $sql = "SELECT COUNT(DISTINCT nomDashboard) AS NB, ROUND(dateMortDashboard/5)*5 AS DATEM FROM Dashboard WHERE dateMortDashboard<>'' AND ROUND(dateMortDashboard/5)*5>1790 AND dateMortDashboard REGEXP '^[0-9]+$' AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2."  GROUP BY ROUND(dateMortDashboard/5)*5 ORDER BY CONVERT(DATEM, SIGNED INTEGER)";
            //$sql = "SELECT COUNT(DISTINCT nomDashboard) AS NB, SUBSTR(dateMortDashboard, 1, 3) AS DATEM FROM Dashboard WHERE dateMortDashboard<>'' AND LENGTH(dateMortDashboard)=4 AND dateMortDashboard REGEXP '^[0-9]+$' GROUP BY SUBSTR(dateMortDashboard, 1, 3) UNION SELECT COUNT(DISTINCT nomDashboard) AS NB, SUBSTR(dateMortDashboard, 1, 2) AS DATEM FROM Dashboard WHERE dateMortDashboard<>'' AND LENGTH(dateMortDashboard)=3 AND dateMortDashboard REGEXP '^[0-9]+$' AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." GROUP BY SUBSTR(dateMortDashboard, 1, 2) ORDER BY CONVERT(DATEM, SIGNED INTEGER)"; 
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 

    public static function getAllDateSuicide($m1,$m2) {
        try { 
            $sql = "SELECT COUNT(DISTINCT nomDashboard) AS NB, ROUND(dateMortDashboard/5)*5 AS DATEM FROM Dashboard WHERE dateMortDashboard<>'' AND ROUND(dateMortDashboard/5)*5>=1980 AND dateMortDashboard REGEXP '^[0-9]+$' AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2."  GROUP BY ROUND(dateMortDashboard/5)*5 ORDER BY CONVERT(DATEM, SIGNED INTEGER)";
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 


    public static function getStreamgraph_3($m1,$m2) {
        try { 
            $sql = "SELECT (SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1890) AS 's1890s', (SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1900) AS 's1900s', (SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1910) AS 's1910s', (SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1920) AS 's1920s', (SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1930) AS 's1930s', (SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1940) AS 's1940s', (SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1950) AS 's1950s', (SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1960) AS 's1960s', (SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1970) AS 's1970s',(SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1980) AS 's1980s',(SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=1990) AS 's1990s',(SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=2000) AS 's2000s',(SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=2010) AS 's2010s', (SELECT CASE WHEN COUNT(DISTINCT b.nomDashboard) IS NOT NULL
                THEN COUNT(DISTINCT b.nomDashboard)
                ELSE 0   
            END AS NB FROM Dashboard b WHERE b.paysDashboard = a.paysDashboard AND ROUND(b.dateMortDashboard/10)*10=2020) AS 's2020s', paysDashboard
FROM Dashboard a
WHERE a.paysDashboard <> '' AND a.dateMortDashboard REGEXP '^[0-9]+$'
GROUP BY a.paysDashboard";
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 

  public static function getUserByName($nomDashboard) { 
        try { 
            $sql = "SELECT * FROM Dashboard WHERE nomDashboard LIKE '%$nomDashboard%'"; 
            // echo $sql;
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "nomDashboard" => $nomDashboard,
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getNbSuicide($m1,$m2) { 
        try { 
            $sql = "SELECT COUNT(*) AS NB FROM Dashboard WHERE CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2.""; 
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getAgeMoyen($m1,$m2) { 
        try { 
            $sql = "SELECT ROUND(AVG(dateMortDashboard-dateNaissanceDashboard)) AS NB FROM Dashboard WHERE CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2.""; 
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getAlea($m1,$m2) { 
        try { 
            $sql = "SELECT * FROM Dashboard WHERE CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." ORDER BY RAND() LIMIT 1";
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getStreamgraph($m1,$m2) { 
        try { 
            $sql = "SELECT ROUND(AVG(dateMortDashboard-dateNaissanceDashboard)) AS DENS,paysDashboard AS COL, dateMortDashboard AS ABS FROM Dashboard WHERE paysDashboard <> '' AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." GROUP BY dateMortDashboard,paysDashboard";
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getStreamgraph_2($m1,$m2, $ABS) { 
        try { 
            $sql = "SELECT DENS, paysDashboard FROM (SELECT ROUND(AVG(dateMortDashboard-dateNaissanceDashboard)) AS DENS,paysDashboard AS COL, dateMortDashboard AS ABS FROM Dashboard WHERE paysDashboard <> '' AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)>=".$m1." AND CONVERT(dateMortDashboard, UNSIGNED INTEGER)<=".$m2." GROUP BY dateMortDashboard,paysDashboard) s WHERE ABS = ".$ABS." GROUP BY paysDashboard";
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }
}
?>
