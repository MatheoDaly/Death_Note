<?php
    require_once File::build_path(array('model', 'Model.php')); // On peut donc utiliser cette fonction 
class modelOMS {
   
  private $idOMS;
  private $paysOMS;
  private $sexeOMS;
  private $anneeOMS;
  private $Deaths1;
  private $Deaths2;
  private $Deaths3;
  private $Deaths4;
  private $Deaths5;
  private $Deaths6;
  private $Deaths7;
  private $Deaths8;
  private $Deaths9;
  private $Deaths10;
  private $Deaths11;
  private $Deaths12;
  private $Deaths13;
  private $Deaths14;
  private $Deaths15;
  private $Deaths16;
  private $Deaths17;
  private $Deaths18;
  private $Deaths19;
  private $Deaths20;
  private $Deaths21;
  private $Deaths22;
  private $Deaths23;
  private $Deaths24;
  private $Deaths25;
  private $Deaths26;

  public function __construct($idOMS = NULL, $paysOMS = NULL, $sexeOMS = NULL, $anneeOMS = NULL, $Deaths1 = NULL, $Deaths2 = NULL, $Deaths3 = NULL, $Deaths4 = NULL, $Deaths5 = NULL, $Deaths6 = NULL, $Deaths7 = NULL, $Deaths8 = NULL, $Deaths9 = NULL, $Deaths10 = NULL, $Deaths11 = NULL, $Deaths12 = NULL, $Deaths13 = NULL, $Deaths14 = NULL, $Deaths15 = NULL, $Deaths16 = NULL, $Deaths17 = NULL, $Deaths18 = NULL, $Deaths19 = NULL, $Deaths20 = NULL, $Deaths21 = NULL, $Deaths22 = NULL, $Deaths23 = NULL, $Deaths24 = NULL, $Deaths25 = NULL, $Deaths26 = NULL) {
    if (!is_null($idOMS) && !is_null($paysOMS) && !is_null($sexeOMS) && !is_null($anneeOMS) && !is_null($Deaths1) && !is_null($Deaths2) && !is_null($Deaths3) && !is_null($Deaths4) && !is_null($Deaths5) && !is_null($Deaths6) && !is_null($Deaths7) && !is_null($Deaths8) && !is_null($Deaths9) && !is_null($Deaths10) && !is_null($Deaths11) && !is_null($Deaths12) && !is_null($Deaths13) && !is_null($Deaths14) && !is_null($Deaths15) && !is_null($Deaths16) && !is_null($Deaths17) && !is_null($Deaths18) && !is_null($Deaths19) && !is_null($Deaths20) && !is_null($Deaths21) && !is_null($Deaths22) && !is_null($Deaths23) && !is_null($Deaths24) && !is_null($Deaths25) && !is_null($Deaths27)) {
    $this->idOMS = $idOMS;
    $this->paysOMS = $paysOMS;
    $this->sexeOMS = $sexeOMS;
    $this->anneeOMS = $anneeOMS;
    $this->$Deaths1 = $Deaths1;
    $this->$Deaths2 = $Deaths2;
    $this->$Deaths3 = $Deaths3;
    $this->$Deaths4 = $Deaths4;
    $this->$Deaths5 = $Deaths5;
    $this->$Deaths6 = $Deaths6;
    $this->$Deaths7 = $Deaths7;
    $this->$Deaths8 = $Deaths8;
    $this->$Deaths9 = $Deaths9;
    $this->$Deaths10 = $Deaths10;
    $this->$Deaths11 = $Deaths11;
    $this->$Deaths12 = $Deaths12;
    $this->$Deaths13 = $Deaths13;
    $this->$Deaths14 = $Deaths14;
    $this->$Deaths15 = $Deaths15;
    $this->$Deaths16 = $Deaths16;
    $this->$Deaths17 = $Deaths17;
    $this->$Deaths18 = $Deaths18;
    $this->$Deaths19 = $Deaths19;
    $this->$Deaths20 = $Deaths20;
    $this->$Deaths21 = $Deaths21;
    $this->$Deaths22 = $Deaths22;
    $this->$Deaths23 = $Deaths23;
    $this->$Deaths24 = $Deaths24;
    $this->$Deaths25 = $Deaths25;
    $this->$Deaths26 = $Deaths26;  
    }
  }
      
  // un getter      
  public function getidOMS() {
       return $this->idOMS;  
  }     
  // un setter 
  public function setidOMS($idOMS) {
       $this->idOMS = $idOMS;
  }
  

  // un getter      
  public function getpaysOMS() {
       return $this->paysOMS;  
  }     
  // un setter 
  public function setpaysOMS($paysOMS) {
       $this->paysOMS = $paysOMS;
  }
  
  // un getter      
  public function getsexeOMS() {
       return $this->sexeOMS;  
  }     
  // un setter 
  public function setsexeOMS($sexeOMS) {
       $this->sexeOMS = $sexeOMS;
  }
  
  // un getter      
  public function getanneeOMS() {
       return $this->anneeOMS;  
  }     
  // un setter 
  public function setanneeOMS($anneeOMS) {
       $this->anneeOMS = $anneeOMS;
  }
  
  public function getDeaths1() {
       return $this->Deaths1;  
  }
  public function setDeaths1($Deaths1) {
       $this->Deaths1 = $Deaths1;
  }
  public function getDeaths2() {
       return $this->Deaths2;  
  }
  public function setDeaths2($Deaths2) {
       $this->Deaths2 = $Deaths2;
  }
  public function getDeaths3() {
       return $this->Deaths3;  
  }
  public function setDeaths3($Deaths3) {
       $this->Deaths3 = $Deaths3;
  }
  public function getDeaths4() {
       return $this->Deaths4;  
  }
  public function setDeaths4($Deaths4) {
       $this->Deaths4 = $Deaths4;
  }
  public function getDeaths5() {
       return $this->Deaths5;  
  }
  public function setDeaths5($Deaths5) {
       $this->Deaths5 = $Deaths5;
  }
  public function getDeaths6() {
       return $this->Deaths6;  
  }
  public function setDeaths6($Deaths6) {
       $this->Deaths6 = $Deaths6;
  }
  public function getDeaths7() {
       return $this->Deaths7;  
  }
  public function setDeaths7($Deaths7) {
       $this->Deaths7 = $Deaths7;
  }
  public function getDeaths8() {
       return $this->Deaths8;  
  }
  public function setDeaths8($Deaths8) {
       $this->Deaths8 = $Deaths8;
  }
  public function getDeaths9() {
       return $this->Deaths9;  
  }
  public function setDeaths9($Deaths9) {
       $this->Deaths9 = $Deaths9;
  }
  public function getDeaths10() {
       return $this->Deaths10;  
  }
  public function setDeaths10($Deaths10) {
       $this->Deaths10 = $Deaths10;
  }
  public function getDeaths11() {
       return $this->Deaths11;  
  }
  public function setDeaths11($Deaths11) {
       $this->Deaths11 = $Deaths11;
  }
  public function getDeaths12() {
       return $this->Deaths12;  
  }
  public function setDeaths12($Deaths12) {
       $this->Deaths12 = $Deaths12;
  }
  public function getDeaths13() {
       return $this->Deaths13;  
  }
  public function setDeaths13($Deaths13) {
       $this->Deaths13 = $Deaths13;
  }
  public function getDeaths14() {
       return $this->Deaths14;  
  }
  public function setDeaths14($Deaths14) {
       $this->Deaths14 = $Deaths14;
  }
  public function getDeaths15() {
       return $this->Deaths15;  
  }
  public function setDeaths15($Deaths15) {
       $this->Deaths15 = $Deaths15;
  }
  public function getDeaths16() {
       return $this->Deaths16;  
  }
  public function setDeaths16($Deaths16) {
       $this->Deaths16 = $Deaths16;
  }
  public function getDeaths17() {
       return $this->Deaths17;  
  }
  public function setDeaths17($Deaths17) {
       $this->Deaths17 = $Deaths17;
  }
  public function getDeaths18() {
       return $this->Deaths18;  
  }
  public function setDeaths18($Deaths18) {
       $this->Deaths18 = $Deaths18;
  }
  public function getDeaths19() {
       return $this->Deaths19;  
  }
  public function setDeaths19($Deaths19) {
       $this->Deaths19 = $Deaths19;
  }
  public function getDeaths20() {
       return $this->Deaths20;  
  }
  public function setDeaths20($Deaths20) {
       $this->Deaths20 = $Deaths20;
  }
  public function getDeaths21() {
       return $this->Deaths21;  
  }
  public function setDeaths21($Deaths21) {
       $this->Deaths21 = $Deaths21;
  }
  public function getDeaths22() {
       return $this->Deaths21;  
  }
  public function setDeaths22($Deaths22) {
       $this->Deaths22 = $Deaths22;
  }
  public function getDeaths23() {
       return $this->Deaths23;  
  }
  public function setDeaths23($Deaths23) {
       $this->Deaths23 = $Deaths23;
  }
  public function getDeaths24() {
       return $this->Deaths24;  
  }
  public function setDeaths24($Deaths24) {
       $this->Deaths24 = $Deaths24;
  }
  public function getDeaths25() {
       return $this->Deaths25;  
  }
  public function setDeaths25($Deaths25) {
       $this->Deaths25 = $Deaths25;
  }
  public function getDeaths26() {
       return $this->Deaths26;  
  }
  public function setDeaths26($Deaths26) {
       $this->Deaths2 = $Deaths2;
  }

      public static function getAllOMSByselCategories($selCategories) { 
          try { 
              //$sql = "SELECT * FROM OMS WHERE nomMarmite LIKE '%$nomC%'"; 
              $sql = "SELECT * FROM OMS, Categories  WHERE selCategories=:selCategories AND idCategories=sexeOMS ORDER BY sexeOMS"; 
              $retour = Model::$pdo->prepare($sql); 
              $values = array(
                  "selCategories" => $selCategories,
              );
              $retour->execute($values);
              $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS'); 
              $tab_obj = $retour->fetchAll(); 
              return $tab_obj;
          } catch(PDOException $e) { 
              if (Conf::getDebug()) { 
                  echo $e->getMessage(); 
              } else { 
                  echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
              } 
              die(); 
          } 
      }

  public static function updateOMSanneeOMS($idOMS, $idOMSIMG) {
    $sql = "UPDATE OMS SET anneeOMS = :idOMSIMG WHERE idOMS=:idOMS";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idOMS" => $idOMS,
    "idOMSIMG" => $idOMSIMG
    );
    $req_prep->execute($values);
  }

  public static function updateOMSpdfOMS($idOMS, $idOMSPDF) {
    $sql = "UPDATE OMS SET pdfOMS = :idOMSPDF WHERE idOMS=:idOMS";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idOMS" => $idOMS,
    "idOMSPDF" => $idOMSPDF
    );
    $req_prep->execute($values);
  }

  public static function deleteMarmite($idOMS) {
    $sql = "DELETE FROM OMS WHERE idOMS=:idOMS";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
        "idOMS" => strip_tags($idOMS),
    );
    $req_prep->execute($values);
  }

  public static function updateOMS($idOMS, $paysOMS, $sexeOMS, $biographieOMS, $dateNaissanceOMS) {
    $sql = "UPDATE OMS SET paysOMS = :paysOMS, sexeOMS = :sexeOMS, biographieOMS = :biographieOMS, dateNaissanceOMS = :dateNaissanceOMS WHERE idOMS=:idOMS";
    $req_prep = Model::$pdo->prepare($sql);

    $values = array(
    "idOMS" => $idOMS,
    "paysOMS" => $paysOMS,
    "sexeOMS" => $sexeOMS,
    "biographieOMS" => $biographieOMS,
    "dateNaissanceOMS" => $dateNaissanceOMS,
    );
    $req_prep->execute($values);
  }

  //////////////////////
  public static function truncateOMS() {
    $sql = 'TRUNCATE TABLE OMS';
    $req_prep = Model::$pdo->prepare($sql);
    $req_prep->execute();
  }

  public static function createOMS($paysOMS, $sexeOMS, $anneeOMS, $biographieOMS, $dateNaissanceOMS, $dateMortOMS, $lieuNaissanceOMS, $lieuMortOMS, $genreOMS) {
        try {
            $sql = 'INSERT INTO OMS (paysOMS, sexeOMS, anneeOMS, biographieOMS, dateNaissanceOMS, dateMortOMS, lieuNaissanceOMS, lieuMortOMS, genreOMS) VALUES (:paysOMS, :sexeOMS, :anneeOMS, :biographieOMS, :dateNaissanceOMS, :dateMortOMS, :lieuNaissanceOMS, :lieuMortOMS, :genreOMS)'; // ON DUPLICATE KEY UPDATE paysOMS=:paysOMS, sexeOMS=:sexeOMS, anneeOMS=:anneeOMS, biographieOMS=:biographieOMS, dateNaissanceOMS=:dateNaissanceOMS, dateMortOMS=:dateMortOMS, lieuNaissanceOMS=:lieuNaissanceOMS, lieuMortOMS=:lieuMortOMS, genreOMS=:genreOMS
            $addMembres = Model::$pdo->prepare($sql);
            $values = array(
            "paysOMS" => strip_tags($paysOMS),
            "sexeOMS" => strip_tags($sexeOMS),
            "anneeOMS" => strip_tags($anneeOMS),
            "biographieOMS" => strip_tags($biographieOMS),
            "dateNaissanceOMS" => strip_tags($dateNaissanceOMS),
            "dateMortOMS" => strip_tags($dateMortOMS),
            "lieuNaissanceOMS" => strip_tags($lieuNaissanceOMS),
            "lieuMortOMS" => strip_tags($lieuMortOMS),
            "genreOMS" => strip_tags($genreOMS)
            );

            $addMembres->execute($values);
        } catch(PDOException $e) {
          if (Conf::getDebug()) {
              echo $e->getMessage();
          } else {
              echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
          }
          die();
        }
    }
  public static function getAllOMS($m1,$m2) {
        try { 
            $sql = "SELECT * FROM OMS,pays WHERE paysOMS=pays.code AND CONVERT(anneeOMS, UNSIGNED INTEGER)>=:m1 AND CONVERT(anneeOMS, UNSIGNED INTEGER)<=:m2";
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "m1" => $m1,
              "m2" => $m2
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 

  public static function getAllSex($m1,$m2) {
        try { 
            $sql = "SELECT SUM(Deaths1) AS NB, sexeOMS FROM OMS WHERE CONVERT(anneeOMS, UNSIGNED INTEGER)>=:m1 AND CONVERT(anneeOMS, UNSIGNED INTEGER)<=:m2 GROUP BY sexeOMS";
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "m1" => $m1,
              "m2" => $m2
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    }

  public static function getAllDateSuicide($m1,$m2) {
        try { 
            $sql = "SELECT SUM(Deaths1) AS NB, anneeOMS AS DATEM FROM OMS WHERE CONVERT(anneeOMS, UNSIGNED INTEGER)>=:m1 AND CONVERT(anneeOMS, UNSIGNED INTEGER)<=:m2 GROUP BY anneeOMS"; 
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "m1" => $m1,
              "m2" => $m2
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    } 
    
    public static function getAllAge($m1, $m2) {
        try { 
            $sql = "SELECT SUM(Deaths2) AS Deaths2, SUM(Deaths3) AS Deaths3, SUM(Deaths4) AS Deaths4, SUM(Deaths5) AS Deaths5, SUM(Deaths6) AS Deaths6, SUM(Deaths7) AS Deaths7, SUM(Deaths8) AS Deaths8, SUM(Deaths9) AS Deaths9, SUM(Deaths10) AS Deaths10, SUM(Deaths11) AS Deaths11, SUM(Deaths12) AS Deaths12, SUM(Deaths13) AS Deaths13, SUM(Deaths14) AS Deaths14, SUM(Deaths15) AS Deaths15, SUM(Deaths16) AS Deaths16, SUM(Deaths17) AS Deaths17, SUM(Deaths18) AS Deaths18, SUM(Deaths19) AS Deaths19, SUM(Deaths20) AS Deaths20, SUM(Deaths21) AS Deaths21, SUM(Deaths22) AS Deaths22, SUM(Deaths23) AS Deaths23, SUM(Deaths24) AS Deaths24, SUM(Deaths25) AS Deaths25 FROM OMS WHERE CONVERT(anneeOMS, SIGNED INTEGER)>=".$m1." AND CONVERT(anneeOMS, SIGNED INTEGER)<=".$m2; 
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelDashboard'); 
            $tab_obj = $retour->fetchAll(); 
            //var_dump($tab_obj);
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
    }

  public static function getUserByName($paysOMS) { 
        try { 
            $sql = "SELECT * FROM OMS WHERE paysOMS LIKE '%$paysOMS%'"; 
            // echo $sql;
            $retour = Model::$pdo->prepare($sql); 
            $values = array(
              "paysOMS" => $paysOMS,
            ); 
            $retour->execute($values);
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj;
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getNbSuicide($m1,$m2) { 
        try { 
            $sql = "SELECT SUM(Deaths1) AS NB FROM OMS WHERE CONVERT(anneeOMS, UNSIGNED INTEGER)>=".$m1." AND CONVERT(anneeOMS, UNSIGNED INTEGER)<=".$m2.""; 
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getMaxPays($m1,$m2) { 
        try { 
            $sql = "SELECT MAX(s.NB) AS NB, nom FROM (SELECT SUM(Deaths1) AS NB, nom FROM OMS,pays WHERE paysOMS=pays.code AND CONVERT(anneeOMS, UNSIGNED INTEGER)>=".$m1." AND CONVERT(anneeOMS, UNSIGNED INTEGER)<=".$m2." GROUP BY paysOMS) s"; 
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getNbBDD($m1,$m2) { 
        try { 
            $sql = "SELECT COUNT(*) AS NB FROM OMS WHERE CONVERT(anneeOMS, UNSIGNED INTEGER)>=".$m1." AND CONVERT(anneeOMS, UNSIGNED INTEGER)<=".$m2.""; 
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

  public static function getAlea($m1,$m2) { 
        try { 
            $sql = "SELECT nom AS NB FROM OMS,pays WHERE paysOMS=pays.code AND CONVERT(anneeOMS, UNSIGNED INTEGER)>=".$m1." AND CONVERT(anneeOMS, UNSIGNED INTEGER)<=".$m2." ORDER BY RAND() LIMIT 1";
            // echo $sql;
            $retour = Model::$pdo->query($sql); 
            $retour->setFetchMode(PDO::FETCH_CLASS, 'modelOMS'); 
            $tab_obj = $retour->fetchAll(); 
            return $tab_obj[0];
        } catch(PDOException $e) { 
            if (Conf::getDebug()) { 
                echo $e->getMessage(); 
            } else { 
                echo "Une erreur est survenue ! Merci de réessayer plus tard"; 
            } 
            die(); 
        } 
  }

}
?>
