<?php
  /**
  * @author Gaël Mullier 
  * Redirection des controller et essai de panier + session
  */

    session_name("deathnote");
   	session_start(); 
    require_once File::build_path(array('controller', 'controllerDashboard.php'));

    /*
    if(isset($_GET['d'])) { 
        $d = $_GET['d']; 
        if(method_exists('controllerDashboard',$d)){
            if($d == "test_maintenance") controllerDashboard::$d();
            else controllerDashboard::maintenance();
        }else{
            controllerDashboard::maintenance();
        }
    } else { 
        controllerDashboard::maintenance();
    } 
     */
      
    if(isset($_GET['d'])) { 
        $d = $_GET['d']; 
        if(method_exists('controllerDashboard',$d)){
            controllerDashboard::$d();
        }else{
            controllerDashboard::error404();
        }
    } else { 
        controllerDashboard::accueil();
    }
?>