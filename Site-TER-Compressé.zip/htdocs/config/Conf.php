<?php
    require_once File::build_path(array('lib', 'File.php'));

class Conf {
   
  static private $databases = array(
   'hostname' => 'sql307.byethost.com',
    'database' => 'b6_25202383_deathnote',
    'login' => 'b6_25202383', //root ""
    'password' => 'Binouxon12'
  );
   
    static private $debug = true;
   
  static public function getLogin() {
    return self::$databases['login'];
  }
  static public function getHostname() {
    return self::$databases['hostname'];
  }
  static public function getDatabase() {
    return self::$databases['database'];
  }
  static public function getPassword() {
    return self::$databases['password'];
  }
  static public function getDebug() { 
            return self::$debug; 
        } 
   
}
?>

